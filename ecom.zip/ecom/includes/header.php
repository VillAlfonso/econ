<?php
// includes/header.php
require_once __DIR__ . '/auth.php';  // ← Loads session + isLoggedIn()
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title ?? 'Cheeze Tea'); ?></title>

    <!-- Tailwind CDN -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <!-- Global or Page-specific CSS -->
    <?php if (!empty($page_css)): ?>
        <link rel="stylesheet" href="<?php echo htmlspecialchars($page_css); ?>">
    <?php else: ?>
        <link rel="stylesheet" href="assets/style.css">
    <?php endif; ?>

    <style>
        .playfair { font-family: 'Playfair Display', serif; }
        .poppins  { font-family: 'Poppins', sans-serif; }
        :root {
            --cream: #fffaf0;
            --yellow-dark: #f59e0b;
            --yellow-warm: #fbbf24;
        }
        .bg-cream   { background-color: var(--cream); }
        .text-brown { color: var(--yellow-dark); }
        .bg-brown   { background-color: var(--yellow-dark); }
        .bg-brown:hover { background-color: var(--yellow-warm); }
    </style>
</head>
<body class="bg-cream poppins text-gray-800 min-h-screen">