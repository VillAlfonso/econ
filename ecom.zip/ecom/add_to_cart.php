<?php
session_start();
require 'includes/db.php';

if(!isset($_POST['product_id'])) {
    header('Location: products.php');
    exit();
}

$id = (int)$_POST['product_id'];

$stmt = $pdo->prepare("SELECT id, name, price FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();

if($product) {
    if(!isset($_SESSION['cart'][$id])) {
        $_SESSION['cart'][$id] = 1;
    } else {
        $_SESSION['cart'][$id]++;
    }
}

header('Location: cart.php');
exit();
?>