<?php
$page_title = "Menu – Cheeze Tea Alaminos";

require 'includes/db.php';
require 'includes/header.php';
require 'includes/navbar.php';

/* Safe query */
try {
    $stmt = $pdo->query("SELECT id, name, price, image, category FROM products ORDER BY id DESC");
} catch (PDOException $e) {
    $stmt = $pdo->query("SELECT id, name, price, image FROM products ORDER BY id DESC");
}
$all_products = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* Categories */
$categories = [
    'milktea'    => ['name' => 'Milk Tea',       'icon' => '🧋'],
    'milkshake'  => ['name' => 'Milkshake',      'icon' => '🥤'],
    'fruittea'   => ['name' => 'Fruit Tea',      'icon' => '🍓'],
    'sparkling'  => ['name' => 'Sparkling Soda', 'icon' => '✨'],
    'coffee'     => ['name' => 'Coffee',         'icon' => '☕'],
    'food'       => ['name' => 'Food & Snacks',  'icon' => '🍪']
];

/* Group products */
$grouped = [];
foreach ($all_products as $p) {

    $cat = 'milktea';

    if (!empty($p['category'])) {
        $candidate = strtolower(trim($p['category']));
        if (isset($categories[$candidate])) {
            $cat = $candidate;
        }
    }

    $grouped[$cat][] = $p;
}
?>

<!-- BACKGROUND ANIMATION safely behind everything -->
<div class="fixed inset-0 -z-10 pointer-events-none overflow-hidden">
    <?php for($i=1;$i<=18;$i++):
        $s = rand(12,36);
        $d = 18 + rand(0,14);
        $del = $i * 0.9;
        $l = rand(2,98);
    ?>
    <div style="position:absolute; left:<?= $l ?>%; animation-delay:<?= $del ?>s;">
        <div
          class="rounded-full bg-white/40 blur-md animate-[float_20s_linear_infinite]"
          style="width:<?= $s ?>px; height:<?= $s ?>px; animation-duration:<?= $d ?>s;">
        </div>
    </div>
    <?php endfor; ?>
</div>

<!-- HERO -->
<section class="py-24 text-center relative z-10">
    <h1 class="text-5xl md:text-7xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-600 to-orange-600 mb-6" data-aos="fade-up">
        Our Full Menu
    </h1>
    <p class="text-xl md:text-2xl text-amber-800" data-aos="fade-up" data-aos-delay="200">
        Choose your kind of happiness
    </p>
</section>

<!-- CATEGORY TABS -->
<div class="sticky top-0 z-40 bg-amber-50/95 backdrop-blur-xl border-b border-amber-200 py-6">
    <div class="max-w-7xl mx-auto px-6">
        <div class="flex justify-center gap-4 md:gap-6 flex-wrap">
            <?php foreach($categories as $key => $cat): ?>
                <button
                    onclick="showCategory('<?= $key ?>')"
                    class="tab-btn px-6 py-3 rounded-full text-lg font-semibold transition-all <?= $key==='milktea' ? 'bg-white shadow-xl text-amber-700' : 'text-gray-700' ?>"
                    data-cat="<?= $key ?>">
                    <span class="mr-2"><?= $cat['icon'] ?></span>
                    <?= $cat['name'] ?>
                </button>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- PRODUCTS -->
<section class="py-16 relative z-10">
<div class="max-w-7xl mx-auto px-6">

<?php foreach($categories as $key => $cat): 
    $products = $grouped[$key] ?? [];
?>

<div id="<?= $key ?>" class="category-section <?= $key === 'milktea' ? '' : 'hidden' ?>">
    
    <h2 class="text-4xl md:text-6xl font-extrabold text-center text-amber-800 mb-12" data-aos="fade-down">
        <?= $cat['icon'] ?> <?= $cat['name'] ?>
    </h2>

    <?php if(empty($products)): ?>
        <p class="text-center text-2xl text-amber-600 py-20">
            More items coming soon!
        </p>
    <?php else: ?>

    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">

    <?php foreach($products as $i => $p):

        $image = (!empty($p['image']) && file_exists(__DIR__."/uploads/".$p['image'])) 
        ? $p['image'] 
        : "placeholder.jpg";
    ?>

    <div data-aos="fade-up" data-aos-delay="<?= ($i % 6) * 80 ?>">
        <div class="bg-white/95 rounded-3xl shadow-xl hover:shadow-2xl border border-amber-100 overflow-hidden flex flex-col h-full">

            <img src="uploads/<?= $image ?>" class="w-full h-72 object-cover">

            <div class="p-6 flex flex-col flex-grow text-center">
                <h3 class="text-2xl font-bold text-amber-800 mb-1">
                    <?= htmlspecialchars($p['name']) ?>
                </h3>

                <p class="text-3xl font-extrabold text-orange-600 mb-6">
                    ₱<?= number_format($p['price'],2) ?>
                </p>

                <div class="flex gap-3 mt-auto">
                    
                    <a href="view_product.php?id=<?= $p['id'] ?>"
                       class="flex-1 bg-amber-500 hover:bg-amber-600 text-white font-bold py-3 rounded-full transition">
                        View
                    </a>

                    <form action="add_to_cart.php" method="POST" class="flex-1">
                        <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                        <button class="w-full bg-emerald-600 hover:bg-emerald-700 text-white rounded-full py-3 font-bold">
                            <i class="fa fa-cart-plus"></i>
                        </button>
                    </form>

                </div>

            </div>
        </div>
    </div>

    <?php endforeach; ?>

    </div>
    <?php endif; ?>
</div>

<?php endforeach; ?>
</div>
</section>

<?php require 'includes/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function(){

  if(typeof AOS !== 'undefined'){
    AOS.init({ duration: 900, once: true });
  }

  window.showCategory = function(id){

    document.querySelectorAll('.category-section').forEach(el => {
      el.classList.add('hidden');
    });

    const target = document.getElementById(id);
    if (target) target.classList.remove('hidden');

    document.querySelectorAll('.tab-btn').forEach(btn=>{
      btn.classList.remove('bg-white','shadow-xl','text-amber-700');
      btn.classList.add('text-gray-700');
    });

    const active = document.querySelector('[data-cat="'+id+'"]');
    if(active){
      active.classList.add('bg-white','shadow-xl','text-amber-700');
      active.classList.remove('text-gray-700');
    }
  };
});
</script>
