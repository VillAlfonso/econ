<?php
// Modified to accept order_id and amount (pesos or centavos) and reuse site config if available
// Try to reuse app config if present
$cfgPath = __DIR__ . '/../includes/config.php';
if (file_exists($cfgPath)) {
    require $cfgPath;
    $secret_key = defined('PAYMONGO_SECRET_KEY') ? PAYMONGO_SECRET_KEY : 'sk_test_dfZGRR1A9SPwLtHH8woPgKfJ';
    $api_url = defined('PAYMONGO_API_URL') ? rtrim(PAYMONGO_API_URL, '/') : 'https://api.paymongo.com/v1';
} else {
    $secret_key = 'sk_test_dfZGRR1A9SPwLtHH8woPgKfJ';
    $api_url = 'https://api.paymongo.com/v1';
}

$order_id = $_GET['order_id'] ?? null;
$amount = $_GET['amount'] ?? null; // can be centavos (4200) or pesos (42 or 42.00)

// Normalize amount into centavos
if ($amount === null) {
    $amount_cents = 10000; // default ₱100.00
} else {
    $amount_raw = trim((string)$amount);
    $amount_raw = preg_replace('/[^0-9\.]/', '', $amount_raw);
    if (strpos($amount_raw, '.') !== false) {
        $amount_cents = (int) round(floatval($amount_raw) * 100);
    } else {
        $amtInt = (int)$amount_raw;
        $amount_cents = ($amtInt < 1000) ? $amtInt * 100 : $amtInt;
    }
}

$method = $_GET['method'] ?? 'gcash';
$allowed = ($method === 'card' || $method === 'maya') ? ['card'] : [$method];

$data = [
  "data" => [
    "attributes" => [
      "amount" => $amount_cents,
      "payment_method_allowed" => $allowed,
      "currency" => "PHP",
      "capture_type" => "automatic"
    ]
  ]
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $api_url . "/payment_intents");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
  "Content-Type: application/json",
  "Accept: application/json",
  "Authorization: Basic " . base64_encode($secret_key . ":")
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr = curl_error($ch);
curl_close($ch);

$result = json_decode($response, true);

if (!isset($result['data'])) {
  echo "<h3>❌ PayMongo Error Response :</h3>";
  echo "<pre>";
  echo htmlspecialchars($response);
  echo "</pre>";
  die();
}

$intent_id = $result['data']['id'];
$client_key = $result['data']['attributes']['client_key'];

// If we have an order_id, update the orders table to save the payment_intent id
$dbPath = __DIR__ . '/../includes/db.php';
if (file_exists($dbPath)) {
  require $dbPath;
  try {
    if ($order_id) {
      $update = $pdo->prepare("UPDATE orders SET payment_id = ? WHERE id = ?");
      $update->execute([$intent_id, $order_id]);
    }
  } catch (Exception $e) {
    // log failure but continue
    @file_put_contents(__DIR__ . '/logs/paymongo_errors.log', date('Y-m-d H:i:s') . " | DB UPDATE FAILED: " . $e->getMessage() . "\n", FILE_APPEND);
  }
}

// Pass order_id and amount through to pay.php so that final redirect can include it
$loc = 'pay.php?pi_id=' . urlencode($intent_id) . '&client_key=' . urlencode($client_key);
if ($order_id) $loc .= '&order_id=' . urlencode($order_id);
if ($amount !== null) $loc .= '&amount=' . urlencode($amount);

header("Location: $loc");
exit;
?>
