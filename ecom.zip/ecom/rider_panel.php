<?php
require 'includes/auth.php';
require 'includes/db.php';

// Only riders or admins can access
if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['rider','admin'])) {
    header("Location: /index.php");
    exit;
}

$rider_id = $_SESSION['user_id'];
$success = null;
$error = null;

// ============================================
// CLAIM DELIVERY
// ============================================
if (isset($_POST['claim_delivery'])) {
    $delivery_id = (int)$_POST['delivery_id'];

    try {
        $stmt = $pdo->prepare("
            UPDATE deliveries
            SET rider_id = ?, accepted_at = NOW(), status = 'accepted'
            WHERE id = ? AND rider_id IS NULL AND status = 'assigned'
        ");
        $stmt->execute([$rider_id, $delivery_id]);

        if ($stmt->rowCount() == 1) {
            $pdo->prepare("
                INSERT INTO rider_status (rider_id, status, last_update)
                VALUES (?, 'on_delivery', NOW())
                ON DUPLICATE KEY UPDATE status='on_delivery', last_update=NOW()
            ")->execute([$rider_id]);

            $pdo->prepare("
                INSERT INTO rider_logs (rider_id, log_type, description)
                VALUES (?, 'accepted_delivery', CONCAT('Accepted delivery ID ', ?))
            ")->execute([$rider_id, $delivery_id]);

            $success = "Delivery #$delivery_id assigned to you!";
        } else {
            $error = "This delivery was already taken by another rider.";
        }

    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}


// ============================================
// MARK AS PICKED UP
// ============================================
if (isset($_POST['picked_up'])) {
    $delivery_id = (int)$_POST['delivery_id'];

    $pdo->prepare("
        UPDATE deliveries
        SET picked_up_at = NOW(), status = 'picked_up'
        WHERE id = ? AND rider_id = ?
    ")->execute([$delivery_id, $rider_id]);

    $pdo->prepare("
        INSERT INTO rider_logs (rider_id, log_type, description)
        VALUES (?, 'picked_up', CONCAT('Picked up delivery ID ', ?))
    ")->execute([$rider_id, $delivery_id]);

    $success = "Marked delivery #$delivery_id as picked up!";
}


// ============================================
// UPLOAD PROOF OF DELIVERY
// ============================================
if (isset($_POST['upload_proof'])) {
    $delivery_id = (int)$_POST['delivery_id'];

    if (!empty($_FILES['proof']['name'])) {
        $fileName = time() . "_" . basename($_FILES['proof']['name']);
        $targetDir = "uploads/proofs/";
        $filePath  = "uploads/proofs/" . $fileName; // path stored in DB (web-accessible)

        if (move_uploaded_file($_FILES['proof']['tmp_name'], $filePath)) {

            $pdo->prepare("INSERT INTO delivery_proofs (delivery_id, image_path) VALUES (?, ?)")
                ->execute([$delivery_id, $filePath]);

            $pdo->prepare("
                INSERT INTO rider_logs (rider_id, log_type, description)
                VALUES (?, 'uploaded_proof', CONCAT('Uploaded proof for delivery ID ', ?))
            ")->execute([$rider_id, $delivery_id]);

            $success = "Delivery proof uploaded!";
        } else {
            $error = "File upload failed.";
        }
    }
}


// ============================================
// FETCH DATA
// ============================================

$available_deliveries = $pdo->query("
    SELECT * FROM deliveries
    WHERE status = 'assigned' AND rider_id IS NULL
")->fetchAll(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("
    SELECT * FROM deliveries
    WHERE rider_id = ? AND status IN ('accepted','picked_up')
");
$stmt->execute([$rider_id]);
$active_deliveries = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("
    SELECT * FROM deliveries
    WHERE rider_id = ? AND status = 'delivered'
    ORDER BY delivered_at DESC
");
$stmt->execute([$rider_id]);
$completed_deliveries = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Rider Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.10/dist/full.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>

<body class="bg-gradient-to-br from-yellow-50 to-amber-50 min-h-screen">

<!-- Include Public Navbar With Rider/Admin Links -->
<?php include 'includes/navbar.php'; ?>

<div class="max-w-6xl mx-auto p-6">

    <h1 class="text-4xl font-bold text-yellow-700 mb-6 playfair">Rider Panel</h1>

    <?php if ($success): ?>
        <div class="alert alert-success mb-4"><?= $success ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-error mb-4"><?= $error ?></div>
    <?php endif; ?>



    <!-- ============================= -->
    <!-- AVAILABLE DELIVERIES -->
    <!-- ============================= -->
    <div class="glass rounded-3xl p-6 mb-10">
        <h2 class="text-2xl font-bold text-yellow-700 mb-4">
            <i class="fas fa-box-open mr-2"></i>Available Deliveries
        </h2>

        <?php if (empty($available_deliveries)): ?>
            <p class="text-gray-500">No deliveries available right now.</p>
        <?php else: ?>
            <div class="space-y-4">
                <?php foreach ($available_deliveries as $d): ?>
                <div class="p-4 bg-white rounded-xl shadow hover:bg-yellow-50 transition border border-yellow-100">
                    <p class="font-bold text-lg">Order #<?= $d['order_id'] ?></p>
                    <p><strong>Pickup:</strong> <?= $d['pickup_address'] ?></p>
                    <p><strong>Dropoff:</strong> <?= $d['dropoff_address'] ?></p>

                    <form method="POST" class="mt-4">
                        <input type="hidden" name="delivery_id" value="<?= $d['id'] ?>">
                        <button name="claim_delivery" class="btn btn-primary">
                            <i class="fas fa-hand-pointer mr-2"></i>I Will Deliver This
                        </button>
                    </form>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>



    <!-- ============================= -->
    <!-- ACTIVE DELIVERIES -->
    <!-- ============================= -->
    <div class="glass rounded-3xl p-6 mb-10">
        <h2 class="text-2xl font-bold text-yellow-700 mb-4">
            <i class="fas fa-motorcycle mr-2"></i>Your Active Deliveries
        </h2>

        <?php if (empty($active_deliveries)): ?>
            <p class="text-gray-500">You have no active deliveries.</p>
        <?php else: ?>
            <div class="space-y-4">
                <?php foreach ($active_deliveries as $d): ?>
                <div class="p-4 bg-white rounded-xl shadow border border-yellow-100">

                    <p class="font-bold text-lg">Delivery #<?= $d['id'] ?></p>
                    <p><strong>Status:</strong> <?= ucfirst($d['status']) ?></p>

                    <?php if ($d['status'] == 'accepted'): ?>
                        <form method="POST" class="mt-3">
                            <input type="hidden" name="delivery_id" value="<?= $d['id'] ?>">
                            <button name="picked_up" class="btn btn-warning">
                                <i class="fas fa-bag-shopping mr-2"></i>Mark as Picked Up
                            </button>
                        </form>
                    <?php endif; ?>

                    <?php if ($d['status'] == 'picked_up'): ?>
                        <form method="POST" enctype="multipart/form-data" class="mt-3">
                            <input type="hidden" name="delivery_id" value="<?= $d['id'] ?>">
                            <input type="file" name="proof" accept="image/*" class="file-input file-input-bordered w-full max-w-xs" required>
                            <button name="upload_proof" class="btn btn-success mt-3">
                                <i class="fas fa-upload mr-2"></i>Upload Delivery Proof
                            </button>
                        </form>
                    <?php endif; ?>

                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>



    <!-- ============================= -->
    <!-- COMPLETED DELIVERIES -->
    <!-- ============================= -->
    <div class="glass rounded-3xl p-6 mb-10">
        <h2 class="text-2xl font-bold text-yellow-700 mb-4">
            <i class="fas fa-check-circle mr-2"></i>Completed Deliveries
        </h2>

        <?php if (empty($completed_deliveries)): ?>
            <p class="text-gray-500">You have no completed deliveries yet.</p>
        <?php else: ?>
            <ul class="space-y-2">
                <?php foreach ($completed_deliveries as $d): ?>
                    <li class="p-3 bg-white rounded-xl shadow border border-yellow-100">
                        Delivery #<?= $d['id'] ?> — Delivered <?= $d['delivered_at'] ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>

</div>


<style>
    .glass {
        background: rgba(255,255,255,0.6);
        backdrop-filter: blur(12px);
        border: 1px solid rgba(255,255,255,0.4);
        box-shadow: 0 10px 30px rgba(251,191,36,0.2);
    }
    .playfair {
        font-family: 'Playfair Display', serif;
    }
</style>

</body>
</html>
