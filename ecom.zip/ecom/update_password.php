<?php
require 'includes/db.php';

// Hash the password 'admin' using bcrypt
$password = 'admin';
$hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]);

echo "New hash for 'admin': " . $hash . "\n";

// Update the database
$stmt = $pdo->prepare("UPDATE users SET password = ? WHERE email = ?");
$result = $stmt->execute([$hash, 'admin@shop.com']);

if ($result) {
    echo "Password updated successfully!\n";
    
    // Verify it works
    $stmt = $pdo->prepare("SELECT password FROM users WHERE email = ?");
    $stmt->execute(['admin@shop.com']);
    $user = $stmt->fetch();
    
    if ($user && password_verify('admin', $user['password'])) {
        echo "✓ Password verification successful!\n";
    } else {
        echo "✗ Password verification failed!\n";
    }
} else {
    echo "Update failed!\n";
}
?>
