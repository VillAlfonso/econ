<?php 
require '../includes/auth.php'; 
requireAdmin(); 
require '../includes/db.php'; 

$page_title = "Manage Customers - Cheeze Tea";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>

    <!-- Tailwind + DaisyUI -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.10/dist/full.min.css" rel="stylesheet">

    <!-- Fonts & Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        body {
            background: linear-gradient(135deg, #fffbeb 0%, #fefce8 100%);
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
        }
        .playfair { font-family: 'Playfair Display', serif; }
        .glass {
            background: rgba(255, 255, 255, 0.3);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.5);
            box-shadow: 0 15px 35px rgba(251, 191, 36, 0.15);
        }
        .table-row:hover {
            background: rgba(253, 230, 138, 0.15) !important;
        }
    </style>
</head>
<body class="text-gray-800">

<div class="flex min-h-screen">

    <!-- Sidebar -->
    <div class="w-64 bg-white shadow-2xl fixed h-full z-10 border-r border-yellow-100">
        <div class="p-8 text-center border-b border-yellow-100">
            <h1 class="playfair text-4xl font-bold text-yellow-600">Cheeze Tea</h1>
            <p class="text-yellow-700 text-sm">Admin Panel</p>
        </div>
        <nav class="mt-8">
            <a href="dashboard.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                <i class="fas fa-tachometer-alt mr-3"></i> Dashboard
            </a>
            <a href="products.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                <i class="fas fa-coffee mr-3"></i> Products
            </a>
            <a href="orders.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                <i class="fas fa-shopping-bag mr-3"></i> Orders
            </a>
            <a href="customers.php" class="block py-4 px-8 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 font-bold">
                <i class="fas fa-users mr-3"></i> Customers
            </a>
            <a href="riders.php" class="block py-4 px-8 hover:bg-yellow-50 hover:border-l-4 hover:border-yellow-500 transition">
                <i class="fas fa-users mr-3"></i> Riders
            </a>
            <a href="../logout.php" class="block py-4 px-8 hover:bg-red-50 hover:text-red-600 transition mt-32">
                <i class="fas fa-sign-out-alt mr-3"></i> Logout
            </a>
            <a href="riders.php" class="block py-4 px-8 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 font-bold">
                <i class="fas fa-motorcycle mr-3"></i> Riders
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="flex-1 ml-64 p-10">

        <!-- Header -->
        <div class="mb-10">
            <h1 class="playfair text-5xl font-bold text-yellow-700">Manage Customers</h1>
            <p class="text-gray-600 mt-2">View all registered customers.</p>
        </div>

        <!-- Customers Table -->
        <div class="glass rounded-3xl overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="bg-gradient-to-r from-yellow-400 to-amber-500 text-white">
                            <th class="px-8 py-6 text-left">ID</th>
                            <th class="px-8 py-6 text-left">Name</th>
                            <th class="px-8 py-6 text-left">Email</th>
                            <th class="px-8 py-6 text-left">Phone</th>
                            <th class="px-8 py-6 text-center">Status</th>
                            <th class="px-8 py-6 text-center">Joined</th>
                            <th class="px-8 py-6 text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-yellow-100">
                        <?php 
                        // Check if users table exists and get non-admin users
                        $tables = $pdo->query("SHOW TABLES LIKE 'users'")->fetchAll();
                        
                        if (!empty($tables)) {
                            $stmt = $pdo->query("SELECT * FROM users WHERE role != 'admin' ORDER BY id DESC");
                            $customers = $stmt->fetchAll();
                            
                            if (!empty($customers)) {
                                foreach($customers as $customer): 
                        ?>
                        <tr class="table-row transition-all duration-300 hover:bg-yellow-50/50">
                            <td class="px-8 py-6">
                                <p class="font-semibold text-lg text-gray-800">#<?php echo htmlspecialchars($customer['id']); ?></p>
                            </td>
                            <td class="px-8 py-6">
                                <p class="font-semibold text-gray-800"><?php echo htmlspecialchars($customer['name']); ?></p>
                            </td>
                            <td class="px-8 py-6">
                                <p class="text-gray-600"><?php echo htmlspecialchars($customer['email']); ?></p>
                            </td>
                            <td class="px-8 py-6">
                                <p class="text-gray-600"><?php echo htmlspecialchars($customer['phone'] ?? 'N/A'); ?></p>
                            </td>
                            <td class="px-8 py-6 text-center">
                                <span class="badge badge-success">Active</span>
                            </td>
                            <td class="px-8 py-6 text-center">
                                <p class="text-sm text-gray-600"><?php echo date('M d, Y', strtotime($customer['created_at'] ?? date('Y-m-d'))); ?></p>
                            </td>
                            <td class="px-8 py-6 text-center">
                                <div class="flex gap-3 justify-center">
                                    <button onclick="alert('Customer: <?php echo htmlspecialchars($customer['name']); ?>\nEmail: <?php echo htmlspecialchars($customer['email']); ?>\nJoined: <?php echo date('M d, Y', strtotime($customer['created_at'] ?? date('Y-m-d'))); ?>')"
                                       class="px-5 py-3 bg-blue-500 text-white rounded-xl hover:bg-blue-600 transition transform hover:scale-110 shadow-lg">
                                        <i class="fas fa-info-circle"></i> Info
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php 
                                endforeach;
                            } else {
                        ?>
                        <tr>
                            <td colspan="7" class="text-center py-16 text-gray-500">
                                <i class="fas fa-users text-6xl mb-4 block text-yellow-300"></i>
                                <p class="text-2xl">No customers yet. They will appear here when users register.</p>
                            </td>
                        </tr>
                        <?php 
                            }
                        } else {
                        ?>
                        <tr>
                            <td colspan="7" class="text-center py-16 text-gray-500">
                                <i class="fas fa-info-circle text-6xl mb-4 block text-yellow-300"></i>
                                <p class="text-2xl">Users table not found.</p>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Floating Action Button (Mobile) -->
        <a href="dashboard.php" class="fixed bottom-8 right-8 w-16 h-16 bg-yellow-500 text-white rounded-full shadow-2xl flex items-center justify-center text-3xl hover:bg-amber-600 transform hover:scale-110 transition z-50 md:hidden">
            <i class="fas fa-home"></i>
        </a>

    </div>
</div>

</body>
</html>
