<?php 
require '../includes/auth.php'; 
requireAdmin(); 
require '../includes/db.php';

$id = $_GET['id'] ?? null;

if (!$id) {
    header('Location: products.php');
    exit();
}

// Fetch product
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();

if (!$product) {
    header('Location: products.php');
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $stock = intval($_POST['stock'] ?? 0);
    $status = $_POST['status'] ?? 'active';
    
    $filename = $product['image']; // Keep existing image by default
    
    // Handle new image upload
    if (!empty($_FILES['image']['name'])) {
        $file = $_FILES['image'];
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = time() . '_' . uniqid() . '.' . $ext;
        
        if (move_uploaded_file($file['tmp_name'], '../uploads/' . $filename)) {
            // Delete old image if it exists
            $old_image = '../uploads/' . $product['image'];
            if (file_exists($old_image) && $product['image']) {
                unlink($old_image);
            }
        } else {
            $filename = $product['image']; // Keep old image if upload fails
        }
    }
    
    // Update product
    $stmt = $pdo->prepare("UPDATE products SET name = ?, description = ?, price = ?, stock = ?, status = ?, image = ? WHERE id = ?");
    $result = $stmt->execute([$name, $description, $price, $stock, $status, $filename, $id]);
    
    if ($result) {
        header('Location: products.php?success=1');
        exit();
    }
}

$page_title = "Edit Product - Cheeze Tea";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>

    <!-- Tailwind + DaisyUI -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.10/dist/full.min.css" rel="stylesheet">

    <!-- Fonts & Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        body {
            background: linear-gradient(135deg, #fffbeb 0%, #fefce8 100%);
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
        }
        .playfair { font-family: 'Playfair Display', serif; }
        .glass {
            background: rgba(255, 255, 255, 0.3);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.5);
            box-shadow: 0 15px 35px rgba(251, 191, 36, 0.15);
        }
    </style>
</head>
<body class="text-gray-800">

<div class="flex min-h-screen">

    <!-- Sidebar -->
    <div class="w-64 bg-white shadow-2xl fixed h-full z-10 border-r border-yellow-100">
        <div class="p-8 text-center border-b border-yellow-100">
            <h1 class="playfair text-4xl font-bold text-yellow-600">Cheeze Tea</h1>
            <p class="text-yellow-700 text-sm">Admin Panel</p>
        </div>
        <nav class="mt-8">
            <a href="dashboard.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                <i class="fas fa-tachometer-alt mr-3"></i> Dashboard
            </a>
            <a href="products.php" class="block py-4 px-8 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 font-bold">
                <i class="fas fa-coffee mr-3"></i> Products
            </a>
            <a href="orders.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                <i class="fas fa-shopping-bag mr-3"></i> Orders
            </a>
            <a href="customers.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                <i class="fas fa-users mr-3"></i> Customers
            </a>
            <a href="../logout.php" class="block py-4 px-8 hover:bg-red-50 hover:text-red-600 transition mt-32">
                <i class="fas fa-sign-out-alt mr-3"></i> Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="flex-1 ml-64 p-10">

        <!-- Header -->
        <div class="mb-10 flex justify-between items-center">
            <div>
                <h1 class="playfair text-5xl font-bold text-yellow-700">Edit Product</h1>
                <p class="text-gray-600 mt-2">Update the product details below</p>
            </div>
            <a href="products.php" class="px-6 py-3 bg-gray-600 text-white rounded-xl hover:bg-gray-700 transition">
                <i class="fas fa-arrow-left mr-2"></i> Back to Products
            </a>
        </div>

        <!-- Form Container -->
        <div class="glass rounded-3xl p-10 max-w-4xl">
            <form method="POST" enctype="multipart/form-data" class="space-y-8">
                
                <!-- Product Name -->
                <div>
                    <label class="block text-lg font-semibold text-gray-800 mb-3">
                        <i class="fas fa-tag mr-2 text-yellow-600"></i> Product Name
                    </label>
                    <input type="text" name="name" required 
                           value="<?php echo htmlspecialchars($product['name']); ?>"
                           class="w-full px-6 py-4 border-2 border-yellow-200 rounded-2xl focus:outline-none focus:border-yellow-600 focus:ring-2 focus:ring-yellow-300 transition" 
                           placeholder="Enter product name">
                </div>

                <!-- Description -->
                <div>
                    <label class="block text-lg font-semibold text-gray-800 mb-3">
                        <i class="fas fa-align-left mr-2 text-yellow-600"></i> Description
                    </label>
                    <textarea name="description" rows="5" 
                              class="w-full px-6 py-4 border-2 border-yellow-200 rounded-2xl focus:outline-none focus:border-yellow-600 focus:ring-2 focus:ring-yellow-300 transition resize-none"
                              placeholder="Enter product description"><?php echo htmlspecialchars($product['description']); ?></textarea>
                </div>

                <!-- Price -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div>
                        <label class="block text-lg font-semibold text-gray-800 mb-3">
                            <i class="fas fa-dollar-sign mr-2 text-yellow-600"></i> Price
                        </label>
                        <input type="number" step="0.01" name="price" required 
                               value="<?php echo number_format($product['price'], 2); ?>"
                               class="w-full px-6 py-4 border-2 border-yellow-200 rounded-2xl focus:outline-none focus:border-yellow-600 focus:ring-2 focus:ring-yellow-300 transition" 
                               placeholder="0.00">
                    </div>

                    <!-- Stock -->
                    <div>
                        <label class="block text-lg font-semibold text-gray-800 mb-3">
                            <i class="fas fa-boxes mr-2 text-yellow-600"></i> Stock
                        </label>
                        <input type="number" name="stock" 
                               value="<?php echo $product['stock'] ?? 0; ?>"
                               class="w-full px-6 py-4 border-2 border-yellow-200 rounded-2xl focus:outline-none focus:border-yellow-600 focus:ring-2 focus:ring-yellow-300 transition" 
                               placeholder="Enter stock quantity">
                    </div>
                </div>

                <!-- Status -->
                <div>
                    <label class="block text-lg font-semibold text-gray-800 mb-3">
                        <i class="fas fa-toggle-on mr-2 text-yellow-600"></i> Status
                    </label>
                    <select name="status" class="w-full px-6 py-4 border-2 border-yellow-200 rounded-2xl focus:outline-none focus:border-yellow-600 focus:ring-2 focus:ring-yellow-300 transition">
                        <option value="active" <?php echo ($product['status'] ?? 'active') === 'active' ? 'selected' : ''; ?>>Active</option>
                        <option value="inactive" <?php echo ($product['status'] ?? 'active') === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                    </select>
                </div>

                <!-- Current Image -->
                <?php if ($product['image']): ?>
                <div>
                    <label class="block text-lg font-semibold text-gray-800 mb-3">
                        <i class="fas fa-image mr-2 text-yellow-600"></i> Current Image
                    </label>
                    <div class="flex items-center gap-6">
                        <div class="w-32 h-32 rounded-2xl overflow-hidden border-4 border-yellow-300 shadow-lg">
                            <img src="../uploads/<?php echo htmlspecialchars($product['image']); ?>" 
                                 alt="<?php echo htmlspecialchars($product['name']); ?>"
                                 class="w-full h-full object-cover">
                        </div>
                        <div>
                            <p class="text-sm text-gray-600 mb-2">Filename: <code class="bg-gray-200 px-2 py-1 rounded"><?php echo htmlspecialchars($product['image']); ?></code></p>
                            <p class="text-sm text-yellow-700 font-medium">Upload a new image to replace this one</p>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Image Upload -->
                <div>
                    <label class="block text-lg font-semibold text-gray-800 mb-3">
                        <i class="fas fa-upload mr-2 text-yellow-600"></i> Upload New Image (Optional)
                    </label>
                    <input type="file" name="image" accept="image/*"
                           class="w-full px-6 py-4 border-2 border-yellow-200 rounded-2xl focus:outline-none focus:border-yellow-600 transition cursor-pointer">
                    <p class="text-sm text-gray-600 mt-2">Supported formats: JPEG, PNG, GIF, WebP</p>
                </div>

                <!-- Buttons -->
                <div class="flex gap-6 pt-8 border-t-2 border-yellow-100">
                    <button type="submit" class="flex-1 px-8 py-4 bg-gradient-to-r from-yellow-500 to-amber-500 text-white font-bold rounded-2xl shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300">
                        <i class="fas fa-save mr-2"></i> Save Changes
                    </button>
                    <a href="products.php" class="flex-1 px-8 py-4 bg-gray-300 text-gray-800 font-bold rounded-2xl hover:bg-gray-400 transition text-center">
                        <i class="fas fa-times mr-2"></i> Cancel
                    </a>
                </div>

            </form>
        </div>

    </div>
</div>

</body>
</html>
