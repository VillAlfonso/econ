<?php 
require '../includes/auth.php'; 
requireAdmin(); 
require '../includes/db.php'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name        = trim($_POST['name'] ?? '');
    $price       = floatval($_POST['price'] ?? 0);
    $category    = $_POST['category'] ?? 'milktea';
    $description = trim($_POST['description'] ?? '');
    $stock       = intval($_POST['stock'] ?? 999);
    $status      = $_POST['status'] ?? 'active';

    $image_name = 'placeholder.jpg'; // default

    if (!empty($_FILES['image']['name'])) {
        $target_dir = "../uploads/";
        $image_name = time() . "_" . basename($_FILES["image"]["name"]);
        $target_file = $target_dir . $image_name;

        // Create uploads folder if not exists
        if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);

        move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
    }

    $stmt = $pdo->prepare("INSERT INTO products (name, price, category, image, description, stock, status, created_at) 
                           VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
    $stmt->execute([$name, $price, $category, $image_name, $description, $stock, $status]);

    header("Location: products.php?success=added");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product – Cheeze Tea Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.10/dist/full.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body { background: linear-gradient(135deg, #fffbeb 0%, #fefce8 100%); font-family: 'Poppins', sans-serif; min-height: 100vh; }
        .playfair { font-family: 'Playfair Display', serif; }
        .glass { background: rgba(255,255,255,0.4); backdrop-filter: blur(15px); border: 1px solid rgba(255,255,255,0.6); box-shadow: 0 20px 40px rgba(251,191,36,0.2); }
    </style>
<head>
<body>

<div class="flex min-h-screen">
    <!-- Sidebar -->
    <div class="w-64 bg-white shadow-2xl fixed h-full z-10 border-r border-yellow-100">
        <div class="p-8 text-center border-b border-yellow-100">
            <h1 class="playfair text-4xl font-bold text-yellow-600">Cheeze Tea</h1>
            <p class="text-yellow-700 text-sm">Admin Panel</p>
        </div>
        <nav class="mt-8">
            <a href="dashboard.php" class="block py-4 px-8 hover:bg-yellow-50 transition">Dashboard</a>
            <a href="products.php" class="block py-4 px-8 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 font-bold">Products</a>
            <a href="orders.php" class="block py-4 px-8 hover:bg-yellow-50 transition">Orders</a>
            <a href="../logout.php" class="block py-4 px-8 hover:bg-red-50 hover:text-red-600 transition mt-32">Logout</a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="flex-1 ml-64 p-10">
        <div class="flex items-center justify-between mb-8">
            <div>
                <h1 class="playfair text-5xl font-bold text-yellow-700">Add New Product</h1>
                <p class="text-gray-600 mt-2">Fill the form below and watch the magic happen</p>
            </div>
            <a href="products.php" class="btn btn-outline border-amber-500 text-amber-700 hover:bg-amber-50">Back to Products</a>
        </div>

        <div class="glass rounded-3xl p-10 max-w-4xl">
            <form method="POST" enctype="multipart/form-data" class="space-y-8">
                <div class="grid md:grid-cols-2 gap-8">
                    <div>
                        <label class="text-lg font-bold text-amber-800">Product Name *</label>
                        <input type="text" name="name" required class="input input-lg w-full mt-2 bg-white/70 border-amber-300" placeholder="Wintermelon Cheese Foam">
                    </div>
                    <div>
                        <label class="text-lg font-bold text-amber-800">Price (₱) *</label>
                        <input type="number" step="0.01" name="price" required class="input input-lg w-full mt-2 bg-white/70 border-amber-300" placeholder="95.00">
                    </div>
                </div>

                <div>
                    <label class="text-lg font-bold text-amber-800">Category *</label>
                    <select name="category" required class="select select-lg w-full mt-2 bg-white/70 border-amber-300">
                        <option value="milktea">Milk Tea</option>
                        <option value="milkshake">Milkshake</option>
                        <option value="fruittea">Fruit Tea</option>
                        <option value="sparkling">Sparkling Soda</option>
                        <option value="coffee">Coffee</option>
                        <option value="food">Food & Snacks</option>
                    </select>
                </div>

                <div>
                    <label class="text-lg font-bold text-amber-800">Product Image</label>
                    <input type="file" name="image" accept="image/*" class="file-input file-input-lg w-full mt-2 bg-white/70 border-amber-300">
                    <p class="text-sm text-gray-600 mt-2">Recommended: 800×800px. Leave blank = placeholder</p>
                </div>

                <div>
                    <label class="text-lg font-bold text-amber-800">Description (Optional)</label>
                    <textarea name="description" rows="4" class="textarea textarea-lg w-full mt-2 bg-white/70 border-amber-300" placeholder="Rich wintermelon syrup with creamy cheese foam..."></textarea>
                </div>

                <div class="grid md:grid-cols-2 gap-8">
                    <div>
                        <label class="text-lg font-bold text-amber-800">Stock (999 = unlimited)</label>
                        <input type="number" name="stock" value="999" class="input input-lg w-full mt-2 bg-white/70 border-amber-300">
                    </div>
                    <div>
                        <label class="text-lg font-bold text-amber-800">Status</label>
                        <select name="status" class="select select-lg w-full mt-2 bg-white/70 border-amber-300">
                            <option value="active">Active (Visible)</option>
                            <option value="inactive">Hidden</option>
                        </select>
                    </div>
                </div>

                <div class="pt-8 flex gap-6">
                    <button type="submit" class="btn btn-lg bg-gradient-to-r from-yellow-500 to-amber-600 text-white px-20 hover:scale-105 transition font-bold shadow-xl">
                        Add Product
                    </button>
                    <a href="products.php" class="btn btn-lg btn-outline border-amber-500 text-amber-700 hover:bg-amber-50">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>

</body>
</html>