<?php 
require '../includes/auth.php'; 
requireAdmin(); 
require '../includes/db.php';

$id = $_GET['id'] ?? null;

if (!$id) {
    header('Location: products.php');
    exit();
}

// Fetch product to get image filename
$stmt = $pdo->prepare("SELECT image FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();

if ($product) {
    // Delete image file if it exists
    $image_path = '../uploads/' . $product['image'];
    if (file_exists($image_path) && $product['image']) {
        unlink($image_path);
    }
    
    // Delete from database
    $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
    $stmt->execute([$id]);
}

header('Location: products.php?deleted=1');
exit();
?>
