<?php 
require '../includes/auth.php'; 
requireAdmin(); 
require '../includes/db.php'; 

$page_title = "Manage Riders - Cheeze Tea";

// Handle assigning a rider via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'])) {
    $user_id = intval($_POST['user_id']);
    $stmt = $pdo->prepare("UPDATE users SET role = 'rider' WHERE id = ?");
    $stmt->execute([$user_id]);
    $success_message = "User assigned as rider successfully!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>

    <!-- Tailwind + DaisyUI -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.10/dist/full.min.css" rel="stylesheet">

    <!-- Fonts & Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        body { background: linear-gradient(135deg, #fffbeb 0%, #fefce8 100%); font-family: 'Poppins', sans-serif; min-height: 100vh; }
        .playfair { font-family: 'Playfair Display', serif; }
        .glass { background: rgba(255, 255, 255, 0.3); backdrop-filter: blur(12px); border: 1px solid rgba(255,255,255,0.5); box-shadow: 0 15px 35px rgba(251,191,36,0.15); }
        .table-row:hover { background: rgba(253,230,138,0.15) !important; }
    </style>
</head>
<body class="text-gray-800">

<div class="flex min-h-screen">

    <!-- Sidebar -->
    <div class="w-64 bg-white shadow-2xl fixed h-full z-10 border-r border-yellow-100">
        <div class="p-8 text-center border-b border-yellow-100">
            <h1 class="playfair text-4xl font-bold text-yellow-600">Cheeze Tea</h1>
            <p class="text-yellow-700 text-sm">Admin Panel</p>
        </div>
        <nav class="mt-8">
            <a href="dashboard.php" class="block py-4 px-8 hover:bg-yellow-50 transition"><i class="fas fa-tachometer-alt mr-3"></i> Dashboard</a>
            <a href="products.php" class="block py-4 px-8 hover:bg-yellow-50 transition"><i class="fas fa-coffee mr-3"></i> Products</a>
            <a href="orders.php" class="block py-4 px-8 hover:bg-yellow-50 transition"><i class="fas fa-shopping-bag mr-3"></i> Orders</a>
            <a href="customers.php" class="block py-4 px-8 hover:bg-yellow-50 transition"><i class="fas fa-users mr-3"></i> Customers</a>
            <a href="riders.php" class="block py-4 px-8 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 font-bold"><i class="fas fa-motorcycle mr-3"></i> Riders</a>
            <a href="../logout.php" class="block py-4 px-8 hover:bg-red-50 hover:text-red-600 transition mt-32"><i class="fas fa-sign-out-alt mr-3"></i> Logout</a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="flex-1 ml-64 p-10">

        <!-- Header -->
        <div class="mb-6 flex justify-between items-center">
            <div>
                <h1 class="playfair text-5xl font-bold text-yellow-700">Manage Riders</h1>
                <p class="text-gray-600 mt-2">View and assign riders.</p>
            </div>
            <button id="toggleAddRider" class="btn btn-primary"><i class="fas fa-plus mr-2"></i> Add Rider</button>
        </div>

        <!-- Add Rider Panel (hidden by default) -->
        <div id="addRiderPanel" class="glass rounded-3xl p-6 mb-6 hidden">
            <h3 class="text-xl font-semibold text-yellow-700 mb-4">Select a user to assign as rider:</h3>
            <input type="text" id="userSearch" placeholder="Search users..." class="input input-bordered w-full mb-4" />
            <div id="userList" class="space-y-2 max-h-64 overflow-y-auto">
                <?php 
                $stmt = $pdo->query("SELECT * FROM users WHERE role NOT IN ('admin', 'rider') ORDER BY name ASC");
                $users = $stmt->fetchAll();
                foreach($users as $user):
                ?>
                <div class="flex justify-between items-center p-3 bg-white rounded-lg shadow hover:bg-yellow-50 transition">
                    <div>
                        <p class="font-semibold"><?php echo htmlspecialchars($user['name']); ?></p>
                        <p class="text-gray-600 text-sm"><?php echo htmlspecialchars($user['email']); ?></p>
                    </div>
                    <form method="POST" class="ml-4">
                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                        <button type="submit" class="btn btn-success btn-sm"><i class="fas fa-user-plus mr-1"></i> Make Rider</button>
                    </form>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Success Message -->
        <?php if(isset($success_message)): ?>
            <div class="alert alert-success mb-6"><?php echo $success_message; ?></div>
        <?php endif; ?>

        <!-- Riders Table -->
        <div class="glass rounded-3xl overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="bg-gradient-to-r from-yellow-400 to-amber-500 text-white">
                            <th class="px-8 py-6 text-left">ID</th>
                            <th class="px-8 py-6 text-left">Name</th>
                            <th class="px-8 py-6 text-left">Email</th>
                            <th class="px-8 py-6 text-left">Phone</th>
                            <th class="px-8 py-6 text-center">Status</th>
                            <th class="px-8 py-6 text-center">Joined</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-yellow-100">
                        <?php 
                        $stmt = $pdo->query("SELECT * FROM users WHERE role = 'rider' ORDER BY id DESC");
                        $riders = $stmt->fetchAll();
                        if(!empty($riders)):
                            foreach($riders as $rider):
                        ?>
                        <tr class="table-row transition-all duration-300 hover:bg-yellow-50/50">
                            <td class="px-8 py-6">#<?php echo htmlspecialchars($rider['id']); ?></td>
                            <td class="px-8 py-6"><?php echo htmlspecialchars($rider['name']); ?></td>
                            <td class="px-8 py-6"><?php echo htmlspecialchars($rider['email']); ?></td>
                            <td class="px-8 py-6"><?php echo htmlspecialchars($rider['phone'] ?? 'N/A'); ?></td>
                            <td class="px-8 py-6 text-center"><span class="badge badge-success">Active</span></td>
                            <td class="px-8 py-6 text-center"><?php echo date('M d, Y', strtotime($rider['created_at'] ?? date('Y-m-d'))); ?></td>
                        </tr>
                        <?php 
                            endforeach;
                        else: 
                        ?>
                        <tr>
                            <td colspan="6" class="text-center py-16 text-gray-500">
                                <i class="fas fa-motorcycle text-6xl mb-4 block text-yellow-300"></i>
                                <p class="text-2xl">No riders yet.</p>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<script>
// Toggle Add Rider Panel
document.getElementById('toggleAddRider').addEventListener('click', function(){
    const panel = document.getElementById('addRiderPanel');
    panel.classList.toggle('hidden');
});

// Simple Search Filter
document.getElementById('userSearch').addEventListener('input', function(){
    const filter = this.value.toLowerCase();
    document.querySelectorAll('#userList > div').forEach(userDiv => {
        const name = userDiv.querySelector('p').textContent.toLowerCase();
        const email = userDiv.querySelectorAll('p')[1].textContent.toLowerCase();
        if(name.includes(filter) || email.includes(filter)) {
            userDiv.style.display = 'flex';
        } else {
            userDiv.style.display = 'none';
        }
    });
});
</script>

</body>
</html>