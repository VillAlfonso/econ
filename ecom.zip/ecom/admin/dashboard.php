<?php 
require '../includes/auth.php';
requireAdmin();
require '../includes/db.php';

$page_title = "Admin Dashboard - Cheeze Tea";

// Stats
$total_products   = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$total_orders     = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$total_users      = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn();
$revenue_today    = $pdo->query("SELECT COALESCE(SUM(total), 0) FROM orders WHERE DATE(created_at) = CURDATE()")->fetchColumn();
$pending_orders   = $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'pending'")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>

    <!-- Tailwind + DaisyUI -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.10/dist/full.min.css" rel="stylesheet" type="text/css" />
    
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        body {
            background: linear-gradient(135deg, #fffbeb 0%, #fefce8 100%);
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
        }
        .playfair { font-family: 'Playfair Display', serif; }
        .glass {
            background: rgba(255, 255, 255, 0.25);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.4);
            box-shadow: 0 15px 35px rgba(251, 191, 36, 0.15);
        }
        .glow-card:hover {
            transform: translateY(-12px);
            box-shadow: 0 25px 50px rgba(251, 191, 36, 0.3);
        }
        .stat-number {
            font-size: 3rem;
            font-weight: 800;
            background: linear-gradient(45deg, #f59e0b, #fbbf24);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .sidebar {
            background: linear-gradient(to bottom, #ffffff, #fffbeb);
            border-right: 1px solid #fde68a;
        }
    </style>
</head>
<body class="text-gray-800">

<div class="flex min-h-screen">

    <!-- Sidebar -->
    <div class="w-64 sidebar shadow-2xl fixed h-full z-10">
        <div class="p-8 text-center">
            <h1 class="playfair text-4xl font-bold text-yellow-600">Cheeze Tea</h1>
            <p class="text-yellow-700 text-sm mt-2">Admin Panel</p>
        </div>
        <nav class="mt-10">
            <a href="dashboard.php" class="block py-4 px-8 bg-yellow-50 border-l-4 border-yellow-500 text-yellow-800 font-semibold">
                <i class="fas fa-tachometer-alt mr-3"></i> Dashboard
            </a>
            <a href="products.php" class="block py-4 px-8 hover:bg-yellow-50 hover:border-l-4 hover:border-yellow-500 transition">
                <i class="fas fa-coffee mr-3"></i> Products
            </a>
            <a href="orders.php" class="block py-4 px-8 hover:bg-yellow-50 hover:border-l-4 hover:border-yellow-500 transition">
                <i class="fas fa-shopping-bag mr-3"></i> Orders <span class="badge badge-error ml-2"><?php echo $pending_orders; ?></span>
            </a>
            <a href="customers.php" class="block py-4 px-8 hover:bg-yellow-50 hover:border-l-4 hover:border-yellow-500 transition">
                <i class="fas fa-users mr-3"></i> Customers
            </a>
            <a href="riders.php" class="block py-4 px-8 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 font-bold">
                <i class="fas fa-motorcycle mr-3"></i> Riders
            </a>
            <a href="../logout.php" class="block py-4 px-8 hover:bg-red-50 hover:text-red-600 transition mt-20">
                <i class="fas fa-sign-out-alt mr-3"></i> Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="flex-1 ml-64 p-10">

        <!-- Header -->
        <div class="mb-10 flex justify-between items-center">
            <div>
                <h2 class="playfair text-5xl font-bold text-yellow-700">Welcome back, Admin!</h2>
                <p class="text-gray-600 mt-2">Here's what's happening with your shop today.</p>
            </div>
            <div class="text-right">
                <p class="text-2xl font-bold text-yellow-600"><?php echo date('l, F j, Y'); ?></p>
            </div>
        </div>

        <!-- Stats Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">

            <!-- Total Products -->
            <div class="glass rounded-3xl p-8 glow-card transition-all duration-500">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-yellow-700 font-semibold text-lg">Total Products</p>
                        <p class="stat-number"><?php echo $total_products; ?></p>
                    </div>
                    <div class="text-6xl text-yellow-200 opacity-50">
                        <i class="fas fa-coffee"></i>
                    </div>
                </div>
            </div>

            <!-- Today's Revenue -->
            <div class="glass rounded-3xl p-8 glow-card transition-all duration-500">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-yellow-700 font-semibold text-lg">Today's Revenue</p>
                        <p class="stat-number">₱<?php echo number_format($revenue_today, 2); ?></p>
                    </div>
                    <div class="text-6xl text-yellow-200 opacity-50">
                        <i class="fas fa-peso-sign"></i>
                    </div>
                </div>
            </div>

            <!-- Total Orders -->
            <div class="glass rounded-3xl p-8 glow-card transition-all duration-500">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-yellow-700 font-semibold text-lg">Total Orders</p>
                        <p class="stat-number"><?php echo $total_orders; ?></p>
                    </div>
                    <div class="text-6xl text-yellow-200 opacity-50">
                        <i class="fas fa-shopping-bag"></i>
                    </div>
                </div>
            </div>

            <!-- Active Customers -->
            <div class="glass rounded-3xl p-8 glow-card transition-all duration-500">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-yellow-700 font-semibold text-lg">Customers</p>
                        <p class="stat-number"><?php echo $total_users; ?></p>
                    </div>
                    <div class="text-6xl text-yellow-200 opacity-50">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="glass rounded-3xl p-10 text-center">
            <h3 class="playfair text-4xl font-bold text-yellow-700 mb-8">Quick Actions</h3>
            <div class="flex flex-wrap gap-6 justify-center">
                <a href="products.php" class="btn btn-primary btn-lg shadow-xl hover:shadow-2xl">
                    <i class="fas fa-plus mr-3"></i> Add New Product
                </a>
                <a href="orders.php" class="btn btn-outline border-yellow-600 text-yellow-600 hover:bg-yellow-600 hover:text-white btn-lg">
                    <i class="fas fa-list mr-3"></i> View Orders (<?php echo $pending_orders; ?> pending)
                </a>
                <a href="add_category.php" class="btn btn-soft bg-white text-yellow-700 border-2 border-yellow-300 hover:bg-yellow-50 btn-lg">
                    <i class="fas fa-tags mr-3"></i> Manage Categories
                </a>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="mt-12 glass rounded-3xl p-8">
            <h3 class="playfair text-3xl font-bold text-yellow-700 mb-6">Recent Activity</h3>
            <div class="space-y-4">
                <div class="flex items-center justify-between p-4 bg-white/50 rounded-2xl">
                    <div class="flex items-center gap-4">
                        <div class="w-12 h-12 bg-yellow-200 rounded-full flex items-center justify-center">
                            <i class="fas fa-shopping-cart text-yellow-700"></i>
                        </div>
                        <div>
                            <p class="font-semibold">New order #1001</p>
                            <p class="text-sm text-gray-600">2 minutes ago</p>
                        </div>
                    </div>
                    <span class="badge badge-success">Completed</span>
                </div>
            </div>
        </div>

    </div>
</div>

<script>
// Simple entrance animation
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.glow-card').forEach((card, i) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(50px)';
        setTimeout(() => {
            card.style.transition = 'all 0.8s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, i * 200);
    });
});
</script>

</body>
</html>