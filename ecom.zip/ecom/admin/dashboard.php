<?php 
require '../includes/auth.php';
requireAdmin();
require '../includes/db.php';

$page_title = "Admin Dashboard - Cheeze Tea";

// Messages for verification actions
$verify_success = null;
$verify_error   = null;

/* ============================================================
   HANDLE DELIVERY VERIFICATION (ADMIN DASHBOARD)
============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify_delivery'])) {
    $delivery_id = (int)$_POST['delivery_id'];

    try {
        // 1. Fetch delivery + rider + order
        $stmt = $pdo->prepare("
            SELECT d.*, 
                   u.id   AS rider_id,
                   u.name AS rider_name,
                   o.total AS order_total
            FROM deliveries d
            LEFT JOIN users u ON d.rider_id = u.id
            LEFT JOIN orders o ON d.order_id = o.id
            WHERE d.id = ?
        ");
        $stmt->execute([$delivery_id]);
        $delivery = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$delivery) {
            throw new Exception("Delivery not found.");
        }
        if (empty($delivery['rider_id'])) {
            throw new Exception("This delivery is not assigned to any rider.");
        }

        // 2. Check proof exists
        $proofCheck = $pdo->prepare("SELECT COUNT(*) FROM delivery_proofs WHERE delivery_id = ?");
        $proofCheck->execute([$delivery_id]);
        if ($proofCheck->fetchColumn() == 0) {
            throw new Exception("Cannot verify. No delivery proof uploaded.");
        }

        // 3. Prevent double verification
        if ($delivery['status'] === 'delivered') {
            throw new Exception("This delivery has already been verified.");
        }

        // 4. Mark delivery as delivered
        $upd = $pdo->prepare("
            UPDATE deliveries
            SET status = 'delivered', delivered_at = NOW()
            WHERE id = ?
        ");
        $upd->execute([$delivery_id]);

        // 5. Insert rider earnings
        $base_pay    = 30.00;
        $rate_per_km = 10.00;
        $distance_km = $delivery['distance_km'] ?? 0;

        $earn = $pdo->prepare("
            INSERT INTO rider_earnings 
                (rider_id, delivery_id, base_pay, distance_km, rate_per_km, bonus, penalty)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $earn->execute([
            $delivery['rider_id'],
            $delivery_id,
            $base_pay,
            $distance_km,
            $rate_per_km,
            0.00,
            0.00
        ]);

        // 6. Update rider status → available
        $statusStmt = $pdo->prepare("
            INSERT INTO rider_status (rider_id, status, last_update)
            VALUES (?, 'available', NOW())
            ON DUPLICATE KEY UPDATE status='available', last_update=NOW()
        ");
        $statusStmt->execute([$delivery['rider_id']]);

        // 7. Log action
        $logStmt = $pdo->prepare("
            INSERT INTO rider_logs (rider_id, log_type, description)
            VALUES (?, 'delivery_verified', CONCAT('Admin verified delivery ID ', ? , ' via dashboard'))
        ");
        $logStmt->execute([$delivery['rider_id'], $delivery_id]);

        $verify_success = "Delivery #{$delivery_id} verified successfully. Rider has been paid.";

    } catch (Exception $e) {
        $verify_error = $e->getMessage();
    }
}

/* ============================================================
   STATS
============================================================ */
$total_products   = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$total_orders     = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$total_users      = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn();
$revenue_today    = $pdo->query("SELECT COALESCE(SUM(total), 0) FROM orders WHERE DATE(created_at) = CURDATE()")->fetchColumn();
$pending_orders   = $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'pending'")->fetchColumn();

/* ============================================================
   FETCH DELIVERIES AWAITING VERIFICATION
   - status = picked_up
   - has at least one proof
============================================================ */
$pendingDeliveriesStmt = $pdo->prepare("
    SELECT d.*, 
           o.total        AS order_total,
           o.created_at   AS order_created_at,
           u.name         AS rider_name
    FROM deliveries d
    JOIN orders o ON d.order_id = o.id
    LEFT JOIN users u ON d.rider_id = u.id
    WHERE d.status = 'picked_up'
      AND EXISTS (
          SELECT 1 FROM delivery_proofs p
          WHERE p.delivery_id = d.id
      )
    ORDER BY d.created_at DESC
    LIMIT 5
");
$pendingDeliveriesStmt->execute();
$pending_deliveries = $pendingDeliveriesStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>

    <!-- Tailwind + DaisyUI -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.10/dist/full.min.css" rel="stylesheet" type="text/css" />
    
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        body {
            background: linear-gradient(135deg, #fffbeb 0%, #fefce8 100%);
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
        }
        .playfair { font-family: 'Playfair Display', serif; }
        .glass {
            background: rgba(255, 255, 255, 0.25);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.4);
            box-shadow: 0 15px 35px rgba(251, 191, 36, 0.15);
        }
        .glow-card:hover {
            transform: translateY(-12px);
            box-shadow: 0 25px 50px rgba(251, 191, 36, 0.3);
        }
        .stat-number {
            font-size: 3rem;
            font-weight: 800;
            background: linear-gradient(45deg, #f59e0b, #fbbf24);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .sidebar {
            background: linear-gradient(to bottom, #ffffff, #fffbeb);
            border-right: 1px solid #fde68a;
        }
    </style>
</head>
<body class="text-gray-800">

<div class="flex min-h-screen">

    <!-- Sidebar -->
    <div class="w-64 sidebar shadow-2xl fixed h-full z-10">
        <div class="p-8 text-center">
            <h1 class="playfair text-4xl font-bold text-yellow-600">Cheeze Tea</h1>
            <p class="text-yellow-700 text-sm mt-2">Admin Panel</p>
        </div>
        <nav class="mt-10">
            <a href="dashboard.php" class="block py-4 px-8 bg-yellow-50 border-l-4 border-yellow-500 text-yellow-800 font-semibold">
                <i class="fas fa-tachometer-alt mr-3"></i> Dashboard
            </a>
            <a href="products.php" class="block py-4 px-8 hover:bg-yellow-50 hover:border-l-4 hover:border-yellow-500 transition">
                <i class="fas fa-coffee mr-3"></i> Products
            </a>
            <a href="orders.php" class="block py-4 px-8 hover:bg-yellow-50 hover:border-l-4 hover:border-yellow-500 transition">
                <i class="fas fa-shopping-bag mr-3"></i> Orders <span class="badge badge-error ml-2"><?php echo $pending_orders; ?></span>
            </a>
            <a href="customers.php" class="block py-4 px-8 hover:bg-yellow-50 hover:border-l-4 hover:border-yellow-500 transition">
                <i class="fas fa-users mr-3"></i> Customers
            </a>
            <a href="riders.php" class="block py-4 px-8 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 font-bold">
                <i class="fas fa-motorcycle mr-3"></i> Riders
            </a>
            <a href="../logout.php" class="block py-4 px-8 hover:bg-red-50 hover:text-red-600 transition mt-20">
                <i class="fas fa-sign-out-alt mr-3"></i> Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="flex-1 ml-64 p-10">

        <!-- Header -->
        <div class="mb-10 flex justify-between items-center">
            <div>
                <h2 class="playfair text-5xl font-bold text-yellow-700">Welcome back, Admin!</h2>
                <p class="text-gray-600 mt-2">Here's what's happening with your shop today.</p>
            </div>
            <div class="text-right">
                <p class="text-2xl font-bold text-yellow-600"><?php echo date('l, F j, Y'); ?></p>
            </div>
        </div>

        <!-- Verification Messages -->
        <?php if ($verify_success): ?>
            <div class="alert alert-success mb-6"><?php echo htmlspecialchars($verify_success); ?></div>
        <?php endif; ?>
        <?php if ($verify_error): ?>
            <div class="alert alert-error mb-6"><?php echo htmlspecialchars($verify_error); ?></div>
        <?php endif; ?>

        <!-- Stats Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">

            <!-- Total Products -->
            <div class="glass rounded-3xl p-8 glow-card transition-all duration-500">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-yellow-700 font-semibold text-lg">Total Products</p>
                        <p class="stat-number"><?php echo $total_products; ?></p>
                    </div>
                    <div class="text-6xl text-yellow-200 opacity-50">
                        <i class="fas fa-coffee"></i>
                    </div>
                </div>
            </div>

            <!-- Today's Revenue -->
            <div class="glass rounded-3xl p-8 glow-card transition-all duration-500">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-yellow-700 font-semibold text-lg">Today's Revenue</p>
                        <p class="stat-number">₱<?php echo number_format($revenue_today, 2); ?></p>
                    </div>
                    <div class="text-6xl text-yellow-200 opacity-50">
                        <i class="fas fa-peso-sign"></i>
                    </div>
                </div>
            </div>

            <!-- Total Orders -->
            <div class="glass rounded-3xl p-8 glow-card transition-all duration-500">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-yellow-700 font-semibold text-lg">Total Orders</p>
                        <p class="stat-number"><?php echo $total_orders; ?></p>
                    </div>
                    <div class="text-6xl text-yellow-200 opacity-50">
                        <i class="fas fa-shopping-bag"></i>
                    </div>
                </div>
            </div>

            <!-- Active Customers -->
            <div class="glass rounded-3xl p-8 glow-card transition-all duration-500">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-yellow-700 font-semibold text-lg">Customers</p>
                        <p class="stat-number"><?php echo $total_users; ?></p>
                    </div>
                    <div class="text-6xl text-yellow-200 opacity-50">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="glass rounded-3xl p-10 text-center">
            <h3 class="playfair text-4xl font-bold text-yellow-700 mb-8">Quick Actions</h3>
            <div class="flex flex-wrap gap-6 justify-center">
                <a href="products.php" class="btn btn-primary btn-lg shadow-xl hover:shadow-2xl">
                    <i class="fas fa-plus mr-3"></i> Add New Product
                </a>
                <a href="orders.php" class="btn btn-outline border-yellow-600 text-yellow-600 hover:bg-yellow-600 hover:text-white btn-lg">
                    <i class="fas fa-list mr-3"></i> View Orders (<?php echo $pending_orders; ?> pending)
                </a>
                <a href="add_category.php" class="btn bg-white text-yellow-700 border-2 border-yellow-300 hover:bg-yellow-50 btn-lg">
                    <i class="fas fa-tags mr-3"></i> Manage Categories
                </a>
            </div>
        </div>

        <!-- Recent Activity: Deliveries Awaiting Verification -->
        <div class="mt-12 glass rounded-3xl p-8">
            <h3 class="playfair text-3xl font-bold text-yellow-700 mb-6">Deliveries Awaiting Verification</h3>

            <?php if (empty($pending_deliveries)): ?>
                <p class="text-gray-500">No deliveries waiting for verification right now.</p>
            <?php else: ?>
                <div class="space-y-4">
                    <?php foreach ($pending_deliveries as $d): ?>
                        <?php
                            // Fetch proofs for this delivery
                            $proofStmt = $pdo->prepare("SELECT image_path FROM delivery_proofs WHERE delivery_id = ?");
                            $proofStmt->execute([$d['id']]);
                            $proofs = $proofStmt->fetchAll(PDO::FETCH_ASSOC);
                        ?>
                        <div class="flex flex-col md:flex-row md:items-center md:justify-between p-4 bg-white/60 rounded-2xl border border-yellow-100">
                            <div class="flex items-start gap-4">
                                <div class="w-12 h-12 bg-yellow-200 rounded-full flex items-center justify-center">
                                    <i class="fas fa-motorcycle text-yellow-700"></i>
                                </div>
                                <div>
                                    <p class="font-semibold">
                                        Delivery #<?php echo $d['id']; ?> 
                                        for Order #<?php echo $d['order_id']; ?> 
                                        — ₱<?php echo number_format($d['order_total'], 2); ?>
                                    </p>
                                    <p class="text-sm text-gray-600">
                                        Rider: <?php echo htmlspecialchars($d['rider_name'] ?? 'Unassigned'); ?> ·
                                        Ordered on <?php echo date('M d, Y H:i', strtotime($d['order_created_at'])); ?>
                                    </p>

                                    <?php if (!empty($proofs)): ?>
                                        <div class="flex gap-3 mt-3 flex-wrap">
                                            <?php foreach ($proofs as $p): ?>
                                                <img src="../<?php echo htmlspecialchars($p['image_path']); ?>" 
                                                     alt="Proof" 
                                                     class="w-20 h-20 object-cover rounded-xl border border-yellow-200 shadow">
                                            <?php endforeach; ?>
                                        </div>
                                    <?php else: ?>
                                        <p class="text-xs text-red-500 mt-2">No proof uploaded (this should not appear here).</p>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="mt-4 md:mt-0 flex flex-col items-end gap-2">
                                <span class="badge badge-warning mb-2 text-xs uppercase tracking-wide">
                                    Awaiting Verification
                                </span>
                                <form method="POST">
                                    <input type="hidden" name="delivery_id" value="<?php echo $d['id']; ?>">
                                    <button name="verify_delivery" class="btn btn-success btn-sm">
                                        <i class="fas fa-check-circle mr-1"></i>Verify & Release Payment
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

    </div>
</div>

<script>
// Simple entrance animation
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.glow-card').forEach((card, i) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(50px)';
        setTimeout(() => {
            card.style.transition = 'all 0.8s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, i * 200);
    });
});
</script>

</body>
</html>
