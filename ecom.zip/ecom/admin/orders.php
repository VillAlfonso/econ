<?php 
require '../includes/auth.php'; 
requireAdmin(); 
require '../includes/db.php'; 

$page_title = "Manage Orders - Cheeze Tea";

// Messages for delivery verification actions
$verify_success = null;
$verify_error   = null;

/* ============================================================
   HANDLE DELIVERY VERIFICATION (ADMIN → ORDERS PAGE)
============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify_delivery'])) {
    $delivery_id = (int)$_POST['delivery_id'];

    try {
        // Fetch delivery + rider + order info
        $stmt = $pdo->prepare("
            SELECT d.*, 
                   u.id   AS rider_id,
                   u.name AS rider_name,
                   o.total AS order_total
            FROM deliveries d
            LEFT JOIN users u ON d.rider_id = u.id
            LEFT JOIN orders o ON d.order_id = o.id
            WHERE d.id = ?
        ");
        $stmt->execute([$delivery_id]);
        $delivery = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$delivery) {
            throw new Exception("Delivery not found.");
        }
        if (empty($delivery['rider_id'])) {
            throw new Exception("This delivery is not assigned to any rider.");
        }

        // Check proof exists
        $proofCheck = $pdo->prepare("SELECT COUNT(*) FROM delivery_proofs WHERE delivery_id = ?");
        $proofCheck->execute([$delivery_id]);
        if ($proofCheck->fetchColumn() == 0) {
            throw new Exception("Cannot verify. No delivery proof uploaded.");
        }

        // Prevent double verification
        if ($delivery['status'] === 'delivered') {
            throw new Exception("This delivery has already been verified.");
        }

        // Mark delivery as delivered
        $upd = $pdo->prepare("
            UPDATE deliveries
            SET status = 'delivered', delivered_at = NOW()
            WHERE id = ?
        ");
        $upd->execute([$delivery_id]);

        // Insert rider earnings
        $base_pay    = 30.00;
        $rate_per_km = 10.00;
        $distance_km = $delivery['distance_km'] ?? 0;

        $earn = $pdo->prepare("
            INSERT INTO rider_earnings 
                (rider_id, delivery_id, base_pay, distance_km, rate_per_km, bonus, penalty)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $earn->execute([
            $delivery['rider_id'],
            $delivery_id,
            $base_pay,
            $distance_km,
            $rate_per_km,
            0.00, // bonus
            0.00  // penalty
        ]);

        // Update rider status → available
        $statusStmt = $pdo->prepare("
            INSERT INTO rider_status (rider_id, status, last_update)
            VALUES (?, 'available', NOW())
            ON DUPLICATE KEY UPDATE status='available', last_update=NOW()
        ");
        $statusStmt->execute([$delivery['rider_id']]);

        // Log action
        $logStmt = $pdo->prepare("
            INSERT INTO rider_logs (rider_id, log_type, description)
            VALUES (?, 'delivery_verified', CONCAT('Admin verified delivery ID ', ? , ' via orders page'))
        ");
        $logStmt->execute([$delivery['rider_id'], $delivery_id]);

        $verify_success = "Delivery #{$delivery_id} verified successfully. Rider has been paid.";

    } catch (Exception $e) {
        $verify_error = $e->getMessage();
    }
}

/* ============================================================
   CHECK EXTRA TABLES (for rider / delivery info)
============================================================ */
$hasDeliveries       = !empty($pdo->query("SHOW TABLES LIKE 'deliveries'")->fetchAll());
$hasDeliveryProofs   = !empty($pdo->query("SHOW TABLES LIKE 'delivery_proofs'")->fetchAll());
$hasRiderEarnings    = !empty($pdo->query("SHOW TABLES LIKE 'rider_earnings'")->fetchAll());
$hasRiderStatus      = !empty($pdo->query("SHOW TABLES LIKE 'rider_status'")->fetchAll());
$hasRiderLogs        = !empty($pdo->query("SHOW TABLES LIKE 'rider_logs'")->fetchAll());

/* ============================================================
   FETCH ORDERS (WITH DELIVERY/RIDER INFO IF TABLES EXIST)
============================================================ */
$orders = [];
$tables = $pdo->query("SHOW TABLES LIKE 'orders'")->fetchAll();

if (!empty($tables)) {
    if ($hasDeliveries && $hasDeliveryProofs) {
        // Orders + deliveries + rider + proof count
        $stmt = $pdo->query("
            SELECT 
                o.*,
                u.name AS account_name,
                d.id   AS delivery_id,
                d.status AS delivery_status,
                d.distance_km,
                r.name AS rider_name,
                COALESCE(p.proofs_count, 0) AS proofs_count
            FROM orders o
            LEFT JOIN users u ON o.user_id = u.id
            LEFT JOIN deliveries d ON d.order_id = o.id
            LEFT JOIN users r ON d.rider_id = r.id
            LEFT JOIN (
                SELECT delivery_id, COUNT(*) AS proofs_count
                FROM delivery_proofs
                GROUP BY delivery_id
            ) p ON p.delivery_id = d.id
            ORDER BY o.created_at DESC
        ");
    } else {
        // Orders + customer (no delivery/rider join)
        $stmt = $pdo->query("
            SELECT 
                o.*,
                u.name AS account_name
            FROM orders o
            LEFT JOIN users u ON o.user_id = u.id
            ORDER BY o.created_at DESC
        ");
    }

    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>

    <!-- Tailwind + DaisyUI -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.10/dist/full.min.css" rel="stylesheet">

    <!-- Fonts & Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        body {
            background: linear-gradient(135deg, #fffbeb 0%, #fefce8 100%);
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
        }
        .playfair { font-family: 'Playfair Display', serif; }
        .glass {
            background: rgba(255, 255, 255, 0.3);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.5);
            box-shadow: 0 15px 35px rgba(251, 191, 36, 0.15);
        }
        .table-row:hover {
            background: rgba(253, 230, 138, 0.15) !important;
        }
    </style>
</head>
<body class="text-gray-800">

<div class="flex min-h-screen">

    <!-- Sidebar -->
    <div class="w-64 bg-white shadow-2xl fixed h-full z-10 border-r border-yellow-100">
        <div class="p-8 text-center border-b border-yellow-100">
            <h1 class="playfair text-4xl font-bold text-yellow-600">Cheeze Tea</h1>
            <p class="text-yellow-700 text-sm">Admin Panel</p>
        </div>
        <nav class="mt-8">
            <a href="dashboard.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                <i class="fas fa-tachometer-alt mr-3"></i> Dashboard
            </a>
            <a href="products.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                <i class="fas fa-coffee mr-3"></i> Products
            </a>
            <a href="orders.php" class="block py-4 px-8 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 font-bold">
                <i class="fas fa-shopping-bag mr-3"></i> Orders
            </a>
            <a href="customers.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                <i class="fas fa-users mr-3"></i> Customers
            </a>
            <a href="riders.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                <i class="fas fa-motorcycle mr-3"></i> Riders
            </a>
            <a href="../logout.php" class="block py-4 px-8 hover:bg-red-50 hover:text-red-600 transition mt-32">
                <i class="fas fa-sign-out-alt mr-3"></i> Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="flex-1 ml-64 p-10">

        <!-- Header -->
        <div class="mb-6 flex justify-between items-center">
            <div>
                <h1 class="playfair text-5xl font-bold text-yellow-700">Manage Orders</h1>
                <p class="text-gray-600 mt-2">View orders, track deliveries, and verify rider payouts.</p>
            </div>
        </div>

        <!-- Verification Messages -->
        <?php if ($verify_success): ?>
            <div class="alert alert-success mb-4"><?php echo htmlspecialchars($verify_success); ?></div>
        <?php endif; ?>
        <?php if ($verify_error): ?>
            <div class="alert alert-error mb-4"><?php echo htmlspecialchars($verify_error); ?></div>
        <?php endif; ?>

        <!-- Orders Table -->
        <div class="glass rounded-3xl overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="bg-gradient-to-r from-yellow-400 to-amber-500 text-white">
                            <th class="px-6 py-4 text-left">Order</th>
                            <th class="px-6 py-4 text-left">Customer</th>
                            <th class="px-6 py-4 text-center">Payment</th>
                            <th class="px-6 py-4 text-center">Order Status</th>
                            <th class="px-6 py-4 text-center">Delivery</th>
                            <th class="px-6 py-4 text-center">Rider</th>
                            <th class="px-6 py-4 text-center">Date</th>
                            <th class="px-6 py-4 text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-yellow-100">
                        <?php if (empty($tables)): ?>
                            <tr>
                                <td colspan="8" class="text-center py-16 text-gray-500">
                                    <i class="fas fa-info-circle text-6xl mb-4 block text-yellow-300"></i>
                                    <p class="text-2xl">Orders table not yet created. Set up your checkout system first.</p>
                                </td>
                            </tr>
                        <?php elseif (empty($orders)): ?>
                            <tr>
                                <td colspan="8" class="text-center py-16 text-gray-500">
                                    <i class="fas fa-shopping-bag text-6xl mb-4 block text-yellow-300"></i>
                                    <p class="text-2xl">No orders yet. Orders will appear here when customers make purchases.</p>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($orders as $order): 
                                $orderStatus   = $order['status'] ?? 'pending';
                                $paymentStatus = $order['payment_status'] ?? 'pending';

                                $deliveryStatus = $hasDeliveries ? ($order['delivery_status'] ?? 'none') : 'N/A';
                                $hasDelivery    = $hasDeliveries && !empty($order['delivery_id']);

                                $canVerify = $hasDelivery 
                                    && $deliveryStatus === 'picked_up'
                                    && $hasDeliveryProofs
                                    && isset($order['proofs_count']) 
                                    && $order['proofs_count'] > 0;
                            ?>
                            <tr class="table-row transition-all duration-300 hover:bg-yellow-50/50">
                                <!-- Order / Total -->
                                <td class="px-6 py-4 align-top">
                                    <p class="font-semibold text-gray-800 text-lg">
                                        #<?php echo htmlspecialchars($order['id']); ?>
                                    </p>
                                    <p class="text-sm text-yellow-700 font-bold">
                                        ₱<?php echo number_format((float)$order['total'], 2); ?>
                                    </p>
                                </td>

                                <!-- Customer -->
                                <td class="px-6 py-4 align-top">
                                    <?php 
                                        $customerName = $order['customer_name'] 
                                            ?? $order['account_name'] 
                                            ?? 'Guest';
                                        $customerEmail = $order['customer_email'] ?? 'N/A';
                                    ?>
                                    <p class="font-semibold text-gray-800">
                                        <?php echo htmlspecialchars($customerName); ?>
                                    </p>
                                    <p class="text-sm text-gray-600">
                                        <?php echo htmlspecialchars($customerEmail); ?>
                                    </p>
                                </td>

                                <!-- Payment Status -->
                                <td class="px-6 py-4 text-center align-top">
                                    <?php 
                                        $payBadgeClass = 'badge-warning';
                                        if ($paymentStatus === 'paid')  $payBadgeClass = 'badge-success';
                                        if ($paymentStatus === 'failed') $payBadgeClass = 'badge-error';
                                    ?>
                                    <span class="badge <?php echo $payBadgeClass; ?> mb-1">
                                        <?php echo strtoupper($paymentStatus); ?>
                                    </span>
                                    <?php if (!empty($order['payment_method'])): ?>
                                        <p class="text-xs text-gray-600 mt-1">
                                            via <?php echo htmlspecialchars($order['payment_method']); ?>
                                        </p>
                                    <?php endif; ?>
                                </td>

                                <!-- Order Status -->
                                <td class="px-6 py-4 text-center align-top">
                                    <?php 
                                        $orderBadgeClass = 'badge-error';
                                        if ($orderStatus === 'completed')  $orderBadgeClass = 'badge-success';
                                        elseif ($orderStatus === 'pending') $orderBadgeClass = 'badge-warning';
                                    ?>
                                    <span class="badge <?php echo $orderBadgeClass; ?>">
                                        <?php echo ucfirst($orderStatus); ?>
                                    </span>
                                </td>

                                <!-- Delivery Status -->
                                <td class="px-6 py-4 text-center align-top">
                                    <?php if (!$hasDeliveries): ?>
                                        <span class="badge">N/A</span>
                                    <?php elseif (!$hasDelivery): ?>
                                        <span class="badge badge-ghost">No delivery</span>
                                    <?php else: ?>
                                        <?php
                                            $delClass = 'badge-ghost';
                                            if ($deliveryStatus === 'assigned')  $delClass = 'badge-info';
                                            if ($deliveryStatus === 'accepted')  $delClass = 'badge-warning';
                                            if ($deliveryStatus === 'picked_up') $delClass = 'badge-warning';
                                            if ($deliveryStatus === 'delivered') $delClass = 'badge-success';
                                            if ($deliveryStatus === 'cancelled') $delClass = 'badge-error';
                                        ?>
                                        <span class="badge <?php echo $delClass; ?>">
                                            <?php echo str_replace('_', ' ', ucfirst($deliveryStatus)); ?>
                                        </span>
                                        <?php if (!empty($order['distance_km'])): ?>
                                            <p class="text-xs text-gray-600 mt-1">
                                                <?php echo (float)$order['distance_km']; ?> km
                                            </p>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>

                                <!-- Rider -->
                                <td class="px-6 py-4 text-center align-top">
                                    <?php if (!$hasDeliveries || !$hasDelivery): ?>
                                        <span class="text-sm text-gray-400">—</span>
                                    <?php else: ?>
                                        <p class="font-semibold text-gray-800">
                                            <?php echo htmlspecialchars($order['rider_name'] ?? 'Unassigned'); ?>
                                        </p>
                                        <?php if ($hasDeliveryProofs && isset($order['proofs_count']) && $order['proofs_count'] > 0): ?>
                                            <p class="text-xs text-green-600 mt-1">
                                                <?php echo (int)$order['proofs_count']; ?> proof(s) uploaded
                                            </p>
                                        <?php else: ?>
                                            <p class="text-xs text-gray-500 mt-1">
                                                No proof yet
                                            </p>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>

                                <!-- Date -->
                                <td class="px-6 py-4 text-center align-top">
                                    <p class="text-sm text-gray-600">
                                        <?php echo date('M d, Y', strtotime($order['created_at'])); ?>
                                    </p>
                                </td>

                                <!-- Actions -->
                                <td class="px-6 py-4 text-center align-top">
                                    <div class="flex flex-col gap-2 items-center">
                                        <a href="view_order.php?id=<?php echo $order['id']; ?>" 
                                           class="px-4 py-2 bg-blue-500 text-white rounded-xl hover:bg-blue-600 transition transform hover:scale-105 shadow">
                                            <i class="fas fa-eye mr-1"></i> View
                                        </a>

                                        <?php if ($canVerify): ?>
                                            <form method="POST" class="mt-1">
                                                <input type="hidden" name="delivery_id" value="<?php echo (int)$order['delivery_id']; ?>">
                                                <button name="verify_delivery" 
                                                        class="px-4 py-2 bg-green-600 text-white rounded-xl hover:bg-green-700 transition text-sm shadow">
                                                    <i class="fas fa-check-circle mr-1"></i>
                                                    Verify & Pay Rider
                                                </button>
                                            </form>
                                        <?php elseif ($hasDelivery && $deliveryStatus === 'delivered'): ?>
                                            <span class="text-xs text-green-600 mt-1 font-semibold">
                                                Rider Paid
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Floating Action Button (Mobile) -->
        <a href="dashboard.php" class="fixed bottom-8 right-8 w-16 h-16 bg-yellow-500 text-white rounded-full shadow-2xl flex items-center justify-center text-3xl hover:bg-amber-600 transform hover:scale-110 transition z-50 md:hidden">
            <i class="fas fa-home"></i>
        </a>

    </div>
</div>

</body>
</html>
