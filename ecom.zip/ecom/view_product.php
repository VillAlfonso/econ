<?php 
require 'includes/header.php'; 
require 'includes/navbar.php'; 
require 'includes/db.php';

if(!isset($_GET['id'])) header('Location: products.php');
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$_GET['id']]);
$product = $stmt->fetch();

if(!$product) header('Location: products.php');
$page_title = $product['name'];
?>

<div class="max-w-4xl mx-auto px-4 py-16">
    <div class="grid md:grid-cols-2 gap-12 bg-white rounded-2xl shadow-xl p-8">
        <div>
            <img src="uploads/<?php echo $product['image']; ?>" class="w-full rounded-xl shadow-lg">
        </div>
        <div class="flex flex-col justify-center">
            <h1 class="playfair text-5xl font-bold mb-4"><?php echo htmlspecialchars($product['name']); ?></h1>
            <p class="text-gray-700 text-lg mb-6"><?php echo nl2br(htmlspecialchars($product['description'])); ?></p>
            <p class="text-4xl font-bold text-yellow-dark mb-8">$<?php echo number_format($product['price'], 2); ?></p>
            
            <form action="add_to_cart.php" method="POST">
                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                <button type="submit" class="w-full bg-yellow-dark text-gray-900 py-4 rounded-lg text-xl hover:bg-yellow-warm transition font-semibold">
                    Add to Cart
                </button>
            </form>
            <a href="products.php" class="mt-4 text-center text-yellow-dark underline">← Back to Products</a>
        </div>
    </div>
</div>

<?php require 'includes/footer.php'; ?>