<?php
$page_title = "Cheeze Tea Alaminos Laguna - Premium Cheese Foam Milk Tea";
require 'includes/db.php';
require 'includes/header.php';
require 'includes/navbar.php';

$best_sellers = $pdo->query("SELECT * FROM products ORDER BY id DESC LIMIT 10")->fetchAll();
$best_sellers = array_merge($best_sellers, array_slice($best_sellers, 0, 3)); // seamless loop
?>

<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title><?= $page_title ?></title>

    <!-- Tailwind + DaisyUI -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.10/dist/full.min.css" rel="stylesheet" />

    <!-- Swiper.js -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>

    <!-- AOS -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>

    <!-- Your Ultimate CSS (with FIXED & UPGRADED floating bubbles) -->
    <link rel="stylesheet" href="assets/css/index.css?v=<?= time() ?>" />
</head>
<body class="bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50 text-gray-800 overflow-x-hidden">

<!-- FLOATING GOLDEN BUBBLES — BACK & BETTER THAN EVER -->
<div class="fixed inset-0 pointer-events-none z-0 overflow-hidden">
    <?php for($i = 1; $i <= 20; $i++): ?>
        <div class="particle" style="
            left: <?= rand(2, 98) ?>%;
            animation-delay: <?= $i * 0.8 ?>s;
            animation-duration: <?= 20 + rand(0, 15) ?>s;
            width: <?= rand(15, 35) ?>px;
            height: <?= rand(15, 35) ?>px;
        "></div>
    <?php endfor; ?>
</div>

<!-- HERO -->
<section class="relative min-h-screen flex items-center justify-center px-6">
    <div class="container mx-auto text-center max-w-5xl">
        <h1 class="hero-gradient-text text-7xl sm:text-8xl md:text-9xl lg:text-10xl font-black leading-tight" data-aos="fade-up">
            Cheeze Tea
        </h1>
        <p class="text-2xl sm:text-3xl md:text-4xl font-medium text-amber-800 mt-8 mb-16 max-w-3xl mx-auto" data-aos="fade-up" data-aos-delay="400">
            Creamy • Dreamy • Made with Love in Alaminos, Laguna
        </p>
        <div class="flex flex-col sm:flex-row gap-8 justify-center" data-aos="fade-up" data-aos-delay="800">
            <a href="#creations" class="btn btn-lg bg-gradient-to-r from-yellow-500 to-amber-600 text-white border-0 text-xl px-14 py-7 rounded-full shadow-2xl hover:shadow-3xl transform hover:scale-105 transition">
                Explore Menu
            </a>
            <a href="#gallery" class="btn btn-lg bg-white/90 backdrop-blur-md text-amber-700 border-4 border-amber-400 hover:bg-amber-50 text-xl px-14 py-7 rounded-full shadow-2xl">
                See Moments
            </a>
        </div>
    </div>
</section>

<!-- SIGNATURE CREATIONS — 3 Products Visible -->
<section id="creations" class="py-32 bg-white relative">
    <div class="container mx-auto px-6 max-w-7xl">
        <h2 class="text-6xl md:text-8xl font-black text-center text-transparent bg-clip-text bg-gradient-to-r from-amber-600 to-orange-600 mb-24" data-aos="fade-down">
            Signature Creations
        </h2>

        <div class="relative overflow-hidden rounded-3xl bg-gradient-to-br from-amber-50/70 to-yellow-50/70 glass py-12">
            <div class="carousel-track flex transition-transform duration-1000 ease-in-out" id="carouselTrack">
                <?php foreach($best_sellers as $p): ?>
                <div class="carousel-slide flex-shrink-0 w-full md:w-1/3 px-6">
                    <div class="card bg-white/95 backdrop-blur-xl rounded-3xl overflow-hidden shadow-xl hover:shadow-3xl transition-all duration-700 h-full border border-amber-100">
                        <figure class="relative overflow-hidden">
                            <img src="uploads/<?= htmlspecialchars($p['image'] ?? 'placeholder.jpg') ?>" class="w-full h-80 object-cover hover:scale-110 transition duration-1000">
                            <div class="absolute top-6 right-6 badge badge-lg bg-amber-500/90 text-white border-0 font-bold text-lg px-5 py-3">Popular</div>
                        </figure>
                        <div class="card-body text-center p-10">
                            <h3 class="text-3xl font-bold text-amber-700 mb-4"><?= htmlspecialchars($p['name']) ?></h3>
                            <p class="text-5xl font-black text-orange-600 mb-8">₱<?= number_format($p['price'], 2) ?></p>
                            <a href="view_product.php?id=<?= $p['id'] ?>" class="btn bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0 w-full rounded-full hover:from-amber-600 hover:to-orange-600 text-lg py-5 shadow-lg hover:shadow-xl transform hover:scale-105 transition">
                                View Details
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="flex justify-center gap-4 mt-12">
                <?php for($i = 0; $i < count($best_sellers) - 3; $i++): ?>
                <button class="dot w-3 h-3 rounded-full <?= $i===0?'bg-amber-600 w-12 shadow-lg':'bg-gray-300' ?> transition-all duration-500"></button>
                <?php endfor; ?>
            </div>
        </div>
    </div>
</section>

<!-- GALLERY SECTION — SWIPER LIKE THE LUXURY HOTEL -->
<section id="gallery" class="py-32 bg-gradient-to-b from-amber-50 to-yellow-50">
    <div class="container mx-auto px-6 max-w-7xl">
        <div class="text-center mb-20" data-aos="fade-up">
            <h2 class="text-5xl sm:text-6xl md:text-7xl font-black text-amber-800 mb-6">Our Moments</h2>
            <p class="text-xl md:text-2xl text-amber-700 max-w-4xl mx-auto leading-relaxed">
                Real smiles. Real drinks. Real love from Alaminos, Laguna.
            </p>
        </div>

        <div class="swiper gallery-swiper my-12">
            <div class="swiper-wrapper">
                <div class="swiper-slide rounded-2xl overflow-hidden shadow-2xl"><img src="uploads/gallery/cheeze1.jpg" alt="" class="w-full h-96 object-cover"></div>
                <div class="swiper-slide rounded-2xl overflow-hidden shadow-2xl"><img src="uploads/gallery/cheeze2.jpg" alt="" class="w-full h-96 object-cover"></div>
                <div class="swiper-slide rounded-2xl overflow-hidden shadow-2xl"><img src="uploads/gallery/cheeze3.jpg" alt="" class="w-full h-96 object-cover"></div>
                <div class="swiper-slide rounded-2xl overflow-hidden shadow-2xl"><img src="uploads/gallery/cheeze4.jpg" alt="" class="w-full h-96 object-cover"></div>
                <div class="swiper-slide rounded-2xl overflow-hidden shadow-2xl"><img src="uploads/gallery/cheeze5.jpg" alt="" class="w-full h-96 object-cover"></div>
                <div class="swiper-slide rounded-2xl overflow-hidden shadow-2xl"><img src="uploads/gallery/cheeze6.jpg" alt="" class="w-full h-96 object-cover"></div>
            </div>
            <div class="swiper-button-next text-amber-700"></div>
            <div class="swiper-button-prev text-amber-700"></div>
            <div class="swiper-pagination"></div>
        </div>

        <div class="text-center mt-12">
            <a href="https://instagram.com" target="_blank" class="inline-flex items-center gap-4 text-2xl font-bold text-amber-700 hover:text-amber-900 transition">
                <i class="fab fa-instagram text-5xl"></i>
                Follow @cheezetea.alaminos for daily magic
            </a>
        </div>
    </div>
</section>

<!-- FINAL CTA -->
<section class="py-32 bg-gradient-to-r from-amber-700 via-orange-600 to-amber-800 text-white text-center relative overflow-hidden">
    <div class="absolute inset-0 bg-black/30"></div>
    <div class="relative z-10 container mx-auto px-6">
        <h2 class="text-6xl sm:text-7xl md:text-9xl font-black mb-10" data-aos="fade-up">Ready for Magic?</h2>
        <a href="products.php" class="btn btn-lg bg-white text-amber-700 hover:bg-yellow-100 text-3xl px-20 py-9 rounded-full shadow-2xl hover:shadow-3xl transform hover:scale-110 transition duration-500" data-aos="zoom-in" data-aos-delay="400">
            Order Your Dream Drink
        </a>
    </div>
</section>

<?php require 'includes/footer.php'; ?>

<script>
    AOS.init({ once: true, duration: 1200, easing: 'ease-out-cubic' });

    // 3-Product Carousel
    const track = document.getElementById('carouselTrack');
    const dots = document.querySelectorAll('.dot');
    let currentIndex = 0;
    const totalRealSlides = <?= count($best_sellers) - 3 ?>;
    let autoPlay;

    function updateCarousel() {
        const offset = -currentIndex * (100 / 3);
        track.style.transform = `translateX(${offset}%)`;
        dots.forEach((dot, i) => {
            dot.classList.toggle('bg-amber-600', i === currentIndex);
            dot.classList.toggle('w-12', i === currentIndex);
            dot.classList.toggle('shadow-lg', i === currentIndex);
            dot.classList.toggle('bg-gray-300', i !== currentIndex);
            dot.classList.toggle('w-3', i !== currentIndex);
        });
    }

    function nextSlide() {
        currentIndex++;
        if (currentIndex >= totalRealSlides) {
            currentIndex = 0;
            track.style.transition = 'none';
            updateCarousel();
            void track.offsetWidth;
            track.style.transition = 'transform 1s ease-in-out';
        }
        updateCarousel();
    }

    autoPlay = setInterval(nextSlide, 4000);
    track.parentElement.addEventListener('mouseenter', () => clearInterval(autoPlay));
    track.parentElement.addEventListener('mouseleave', () => autoPlay = setInterval(nextSlide, 4000));
    dots.forEach((dot, i) => dot.addEventListener('click', () => { currentIndex = i; updateCarousel(); clearInterval(autoPlay); autoPlay = setInterval(nextSlide, 4000); }));

    // Swiper Gallery
    const gallerySwiper = new Swiper('.gallery-swiper', {
        loop: true,
        grabCursor: true,
        centeredSlides: true,
        slidesPerView: 1.2,
        spaceBetween: 20,
        autoplay: { delay: 5000 },
        navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' },
        pagination: { el: '.swiper-pagination', clickable: true },
        breakpoints: { 640: { slidesPerView: 2 }, 1024: { slidesPerView: 3 } },
        effect: 'coverflow',
        coverflowEffect: { rotate: 0, stretch: 0, depth: 200, modifier: 1, slideShadows: false }
    });
</script>
</body>
</html>