<?php
// oauth/google.php
session_start();
require '../includes/config.php';

$codeVerifier = bin2hex(random_bytes(32));
$_SESSION['google_code_verifier'] = $codeVerifier;
$codeChallenge = rtrim(strtr(base64_encode(hash('sha256', $codeVerifier, true)), '+/', '-_'), '=');

$authUrl = 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query([
    'client_id'     => GOOGLE_CLIENT_ID,
    'redirect_uri'  => GOOGLE_REDIRECT_URI,
    'response_type' => 'code',
    'scope'         => 'openid email profile',
    'code_challenge'=> $codeChallenge,
    'code_challenge_method' => 'S256',
    'access_type'   => 'offline',
    'prompt'        => 'consent'
]);

header('Location: ' . $authUrl);
exit();
?>