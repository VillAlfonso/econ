<?php
// oauth/google_callback.php
session_start();
require '../includes/config.php';
require '../includes/db.php';

if (!isset($_GET['code'])) {
    die('Error: No code received');
}

$code = $_GET['code'];
$verifier = $_SESSION['google_code_verifier'] ?? '';

$tokenResponse = file_get_contents('https://oauth2.googleapis.com/token', false, stream_context_create([
    'http' => [
        'method' => 'POST',
        'header' => "Content-Type: application/x-www-form-urlencoded",
        'content' => http_build_query([
            'client_id'     => GOOGLE_CLIENT_ID,
            'client_secret' => GOOGLE_CLIENT_SECRET,
            'redirect_uri'  => GOOGLE_REDIRECT_URI,
            'grant_type'    => 'authorization_code',
            'code'          => $code,
            'code_verifier' => $verifier
        ])
    ]
]));

$token = json_decode($tokenResponse, true);

if (!isset($token['access_token'])) {
    die('Login failed: ' . ($token['error_description'] ?? 'Unknown error'));
}

$userInfo = json_decode(file_get_contents('https://www.googleapis.com/oauth2/v2/userinfo?access_token=' . $token['access_token']), true);

$email = $userInfo['email'];
$name  = $userInfo['name'];

// Check if user exists → login or register
$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch();

if ($user) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['name']    = $user['name'];
    $_SESSION['role']    = $user['role'];
} else {
    $stmt = $pdo->prepare("INSERT INTO users (name, email, role) VALUES (?, ?, 'customer')");
    $stmt->execute([$name, $email]);
    $_SESSION['user_id'] = $pdo->lastInsertId();
    $_SESSION['name']    = $name;
    $_SESSION['role']    = 'customer';
}

header('Location: ../index.php');
exit();
?>