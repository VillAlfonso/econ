<?php
// paymongo/process_payment.php - Create PayMongo Payment Intent

session_start();
require '../includes/config.php';
require '../includes/db.php';
require '../includes/auth.php';

if (!isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

// Get order data from POST
$order_id = $_POST['order_id'] ?? null;
$amount = $_POST['amount'] ?? null; // could be pesos (e.g. "42" or "42.00") or centavos (e.g. "4200")
$customer_name = $_POST['customer_name'] ?? $_SESSION['name'];
$customer_email = $_POST['customer_email'] ?? null;

if (!$order_id || !$amount) {
    echo json_encode(['success' => false, 'error' => 'Missing order or amount']);
    exit();
}

// Verify order belongs to user
$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$stmt->execute([$order_id, $_SESSION['user_id']]);
$order = $stmt->fetch();

if (!$order) {
    echo json_encode(['success' => false, 'error' => 'Order not found']);
    exit();
}

// Normalize amount into centavos (integer)
$amount_raw = trim((string)$amount);
$amount_raw = preg_replace('/[^0-9\.]/', '', $amount_raw);
if ($amount_raw === '') {
    echo json_encode(['success' => false, 'error' => 'Invalid amount']);
    exit();
}
if (strpos($amount_raw, '.') !== false) {
    // If amount contains a decimal, assume pesos and convert to centavos
    $amount_cents = (int) round(floatval($amount_raw) * 100);
} else {
    // If it's an integer, decide whether it is pesos or centavos.
    // Heuristic: values < 1000 are likely pesos (e.g. 42 => 4200 centavos).
    $amtInt = (int)$amount_raw;
    if ($amtInt < 1000) {
        $amount_cents = $amtInt * 100;
    } else {
        $amount_cents = $amtInt;
    }
}

// Create PayMongo Payment Intent
$paymentData = [
    "data" => [
        "attributes" => [
            "amount" => (int)$amount_cents,
            "payment_method_allowed" => ["gcash", "card"],
            "payment_method_options" => [
                "card" => [
                    "request_three_d_secure" => "any"
                ]
            ],
            "currency" => "PHP",
            "capture_type" => "automatic",
            "description" => "Order #" . $order_id . " - " . $customer_name
        ]
    ]
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, PAYMONGO_API_URL . "/payment_intents");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($paymentData));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "Accept: application/json",
    "Authorization: Basic " . base64_encode(PAYMONGO_SECRET_KEY . ":")
]);

// Execute request
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr = curl_error($ch);
curl_close($ch);

// Ensure logs directory exists
$logDir = __DIR__ . '/logs';
if (!is_dir($logDir)) {
    @mkdir($logDir, 0755, true);
}
$logFile = $logDir . '/paymongo_errors.log';
$logEntry = date('Y-m-d H:i:s') . " | HTTP:" . $httpCode . " | CURLERR:" . $curlErr . " | REQUEST:" . json_encode($paymentData) . " | RESPONSE:" . $response . "\n";
@file_put_contents($logFile, $logEntry, FILE_APPEND);

$result = json_decode($response, true);

if ($httpCode !== 200 && $httpCode !== 201) {
    echo json_encode([
        'success' => false,
        'error' => 'Failed to create payment intent',
        'details' => $response
    ]);
    exit();
}

if (!isset($result['data']['id'])) {
    echo json_encode([
        'success' => false,
        'error' => 'Invalid PayMongo response',
        'details' => $response
    ]);
    exit();
}

$payment_intent_id = $result['data']['id'];
$client_key = $result['data']['attributes']['client_key'] ?? null;

// Update order with payment intent ID
$updateStmt = $pdo->prepare("UPDATE orders SET payment_id = ? WHERE id = ?");
$updateStmt->execute([$payment_intent_id, $order_id]);

// Return success with payment details
echo json_encode([
    'success' => true,
    'payment_intent_id' => $payment_intent_id,
    'client_key' => $client_key,
    'public_key' => PAYMONGO_PUBLIC_KEY
]);
exit();
?>
