<?php
// paymongo/failed.php - Payment Failed Handler

session_start();
require '../includes/db.php';
require '../includes/header.php';
require '../includes/navbar.php';

$error = $_GET['error'] ?? 'Payment processing failed. Please try again.';
$order_id = $_GET['order_id'] ?? null;
?>

<div class="min-h-screen flex items-center justify-center px-4">
    <div class="max-w-2xl w-full text-center">
        <div class="bg-white rounded-3xl shadow-2xl p-12">
            <!-- Error Icon -->
            <div class="mb-8">
                <div class="w-24 h-24 bg-red-100 rounded-full flex items-center justify-center mx-auto">
                    <i class="fas fa-times-circle text-5xl text-red-600"></i>
                </div>
            </div>

            <!-- Error Message -->
            <h1 class="playfair text-5xl font-bold text-red-600 mb-4">Payment Failed</h1>
            
            <div class="bg-red-50 border-2 border-red-200 rounded-2xl p-6 my-8">
                <p class="text-gray-700 text-lg mb-4">Unfortunately, your payment could not be processed.</p>
                
                <div class="bg-white p-4 rounded-xl my-6 text-left">
                    <p class="text-sm text-gray-600 mb-2">Error Details:</p>
                    <p class="text-gray-800 font-semibold"><?php echo htmlspecialchars($error); ?></p>
                </div>

                <p class="text-gray-700 mb-4">
                    <strong>What you can do:</strong><br>
                    • Check that your payment details are correct<br>
                    • Ensure you have sufficient funds<br>
                    • Try again with a different payment method<br>
                    • Contact our support team for assistance
                </p>
            </div>

            <!-- Actions -->
            <div class="flex gap-4 justify-center flex-wrap">
                <?php if ($order_id): ?>
                    <a href="../checkout.php?retry=<?php echo $order_id; ?>" class="px-8 py-4 bg-yellow-dark text-gray-900 rounded-2xl font-bold hover:bg-yellow-warm transition">
                        <i class="fas fa-redo mr-2"></i> Try Again
                    </a>
                <?php endif; ?>
                <a href="../cart.php" class="px-8 py-4 bg-blue-600 text-white rounded-2xl font-bold hover:bg-blue-700 transition">
                    <i class="fas fa-shopping-cart mr-2"></i> Back to Cart
                </a>
                <a href="../index.php" class="px-8 py-4 bg-gray-600 text-white rounded-2xl font-bold hover:bg-gray-700 transition">
                    <i class="fas fa-home mr-2"></i> Home
                </a>
            </div>
        </div>
    </div>
</div>

<?php require '../includes/footer.php'; ?>
