<?php
// paymongo/success.php - Payment Success Handler

session_start();
require '../includes/db.php';
require '../includes/header.php';
require '../includes/navbar.php';

$payment_intent_id = $_GET['pi_id'] ?? null;

if (!$payment_intent_id) {
    echo '<div class="text-center py-20"><h1 class="text-3xl playfair text-red-600">Payment Failed</h1><p class="text-lg mt-4">No payment information found.</p><a href="../index.php" class="mt-8 inline-block bg-yellow-dark text-gray-900 px-8 py-4 rounded-lg font-semibold">Back to Home</a></div>';
    require '../includes/footer.php';
    exit();
}

// Find order by payment_id and update status
$stmt = $pdo->prepare("SELECT * FROM orders WHERE payment_id = ?");
$stmt->execute([$payment_intent_id]);
$order = $stmt->fetch();

if (!$order) {
    echo '<div class="text-center py-20"><h1 class="text-3xl playfair text-red-600">Order Not Found</h1><p class="text-lg mt-4">We could not find your order.</p><a href="../index.php" class="mt-8 inline-block bg-yellow-dark text-gray-900 px-8 py-4 rounded-lg font-semibold">Back to Home</a></div>';
    require '../includes/footer.php';
    exit();
}

// Update order status to completed
$updateStmt = $pdo->prepare("UPDATE orders SET status = 'completed', payment_status = 'paid' WHERE id = ?");
$updateStmt->execute([$order['id']]);

// Clear cart from session
unset($_SESSION['cart']);
?>

<div class="min-h-screen flex items-center justify-center px-4">
    <div class="max-w-2xl w-full text-center">
        <div class="bg-white rounded-3xl shadow-2xl p-12">
            <!-- Success Icon -->
            <div class="mb-8">
                <div class="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                    <i class="fas fa-check-circle text-5xl text-green-600"></i>
                </div>
            </div>

            <!-- Success Message -->
            <h1 class="playfair text-5xl font-bold text-green-600 mb-4">Payment Successful!</h1>
            
            <div class="bg-green-50 border-2 border-green-200 rounded-2xl p-6 my-8">
                <p class="text-gray-700 text-lg mb-4">Thank you for your purchase! Your payment has been received.</p>
                
                <div class="grid grid-cols-2 gap-6 my-8 text-left">
                    <div class="bg-white p-4 rounded-xl">
                        <p class="text-sm text-gray-600">Order Number</p>
                        <p class="text-2xl font-bold text-yellow-600">#<?php echo $order['id']; ?></p>
                    </div>
                    <div class="bg-white p-4 rounded-xl">
                        <p class="text-sm text-gray-600">Order Total</p>
                        <p class="text-2xl font-bold text-yellow-600">₱<?php echo number_format($order['total'], 2); ?></p>
                    </div>
                    <div class="bg-white p-4 rounded-xl">
                        <p class="text-sm text-gray-600">Payment Status</p>
                        <p class="text-2xl font-bold text-green-600">PAID</p>
                    </div>
                    <div class="bg-white p-4 rounded-xl">
                        <p class="text-sm text-gray-600">Order Date</p>
                        <p class="text-2xl font-bold text-gray-800"><?php echo date('M d, Y', strtotime($order['created_at'])); ?></p>
                    </div>
                </div>

                <p class="text-gray-700 mb-4">We will process your order shortly and send you a confirmation email with tracking information.</p>
            </div>

            <!-- Actions -->
            <div class="flex gap-4 justify-center">
                <a href="../index.php" class="px-8 py-4 bg-yellow-dark text-gray-900 rounded-2xl font-bold hover:bg-yellow-warm transition">
                    <i class="fas fa-home mr-2"></i> Back to Home
                </a>
                <a href="../products.php" class="px-8 py-4 bg-gray-600 text-white rounded-2xl font-bold hover:bg-gray-700 transition">
                    <i class="fas fa-shopping-bag mr-2"></i> Continue Shopping
                </a>
            </div>
        </div>
    </div>
</div>

<?php require '../includes/footer.php'; ?>
