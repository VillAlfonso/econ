<?php
// register.php - PREMIUM CHEEZE TEA REGISTRATION PAGE (2025)
$page_title = "Register - Cheeze Tea";
require 'includes/db.php';
require 'includes/header.php';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    // Validation
    if (!$name) {
        $error = 'Please enter your full name.';
    } elseif (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters long.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        // Check if email already exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = 'Email already registered. Please use another email or login.';
        } else {
            // Hash password and register
            $hashed = password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]);
            
            try {
                $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
                $stmt->execute([$name, $email, $hashed, 'customer']);
                
                $success = 'Registration successful! Redirecting to login...';
                
                echo "<script>
                    Swal.fire({
                        icon: 'success',
                        title: 'Welcome, " . htmlspecialchars($name) . "!',
                        text: 'Your account has been created. Redirecting to login...',
                        timer: 2000,
                        showConfirmButton: false
                    }).then(() => { location.href = 'login.php'; });
                </script>";
                exit();
            } catch (PDOException $e) {
                $error = 'Registration failed. Please try again.';
            }
        }
    }
}
?>

<!-- Floating Background Bubbles -->
<div class="fixed inset-0 overflow-hidden pointer-events-none z-0">
    <div class="absolute w-96 h-96 bg-yellow-200/20 rounded-full blur-3xl -top-48 -left-48 animate-pulse"></div>
    <div class="absolute w-80 h-80 bg-amber-300/30 rounded-full blur-3xl top-1/3 right-0 animate-pulse delay-1000"></div>
    <div class="absolute w-64 h-64 bg-yellow-100/40 rounded-full blur-2xl bottom-0 left-1/3 animate-pulse delay-500"></div>
</div>

<div class="min-h-screen flex items-center justify-center px-4 relative z-10 py-12">
    <div class="max-w-md w-full">

        <!-- Logo & Title -->
        <div class="text-center mb-10 animate-fade-in">
            <h1 class="playfair text-7xl font-bold text-yellow-600 drop-shadow-lg">Cheeze Tea</h1>
            <p class="text-2xl text-amber-700 mt-4 font-medium">Join us today!</p>
            <p class="text-gray-600 mt-2">Create your account and start enjoying</p>
        </div>

        <!-- Registration Card -->
        <div class="bg-white/90 backdrop-blur-xl rounded-3xl shadow-2xl p-10 border border-yellow-100 animate-fade-in-up">
            
            <?php if ($error): ?>
                <div class="bg-red-100 border border-red-300 text-red-700 px-6 py-4 rounded-xl mb-6 text-center font-medium">
                    <i class="fas fa-exclamation-circle mr-2"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="bg-green-100 border border-green-300 text-green-700 px-6 py-4 rounded-xl mb-6 text-center font-medium">
                    <i class="fas fa-check-circle mr-2"></i>
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <!-- Registration Form -->
            <form method="POST" class="space-y-5">
                <!-- Full Name -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        <i class="fas fa-user mr-2 text-yellow-600"></i> Full Name
                    </label>
                    <input type="text" name="name" required placeholder="Juan Dela Cruz"
                           value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>"
                           class="w-full px-6 py-4 rounded-2xl border-2 border-yellow-200 focus:border-yellow-500 focus:outline-none focus:ring-4 focus:ring-yellow-200/50 transition text-lg">
                </div>

                <!-- Email -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        <i class="fas fa-envelope mr-2 text-yellow-600"></i> Email Address
                    </label>
                    <input type="email" name="email" required placeholder="your.email@example.com"
                           value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                           class="w-full px-6 py-4 rounded-2xl border-2 border-yellow-200 focus:border-yellow-500 focus:outline-none focus:ring-4 focus:ring-yellow-200/50 transition text-lg">
                </div>

                <!-- Password -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        <i class="fas fa-lock mr-2 text-yellow-600"></i> Password
                    </label>
                    <input type="password" name="password" required placeholder="At least 6 characters"
                           class="w-full px-6 py-4 rounded-2xl border-2 border-yellow-200 focus:border-yellow-500 focus:outline-none focus:ring-4 focus:ring-yellow-200/50 transition text-lg">
                    <p class="text-xs text-gray-500 mt-2">Must be at least 6 characters</p>
                </div>

                <!-- Confirm Password -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        <i class="fas fa-check-circle mr-2 text-yellow-600"></i> Confirm Password
                    </label>
                    <input type="password" name="confirm_password" required placeholder="Repeat your password"
                           class="w-full px-6 py-4 rounded-2xl border-2 border-yellow-200 focus:border-yellow-500 focus:outline-none focus:ring-4 focus:ring-yellow-200/50 transition text-lg">
                </div>

                <!-- Terms & Conditions -->
                <div class="flex items-start gap-3 pt-2">
                    <input type="checkbox" id="terms" required class="w-5 h-5 rounded accent-yellow-600 mt-1">
                    <label for="terms" class="text-sm text-gray-600">
                        I agree to the <a href="#" class="text-yellow-600 font-semibold hover:underline">Terms of Service</a> and <a href="#" class="text-yellow-600 font-semibold hover:underline">Privacy Policy</a>
                    </label>
                </div>

                <!-- Register Button -->
                <button type="submit" class="w-full bg-gradient-to-r from-yellow-500 to-amber-500 text-white font-bold py-5 rounded-2xl text-xl shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300 mt-8">
                    <i class="fas fa-user-plus mr-2"></i> Create My Account
                </button>
            </form>

            <!-- Divider -->
            <div class="flex items-center my-8">
                <div class="flex-1 border-t border-yellow-200"></div>
                <span class="px-4 text-gray-500 font-medium text-sm">or register with</span>
                <div class="flex-1 border-t border-yellow-200"></div>
            </div>

            <!-- Social Registration -->
            <div class="grid grid-cols-1 gap-4">
                <a href="oauth/google.php" class="flex items-center justify-center gap-4 bg-white border-2 border-gray-300 hover:border-red-400 px-6 py-4 rounded-2xl shadow-md hover:shadow-xl transform hover:scale-105 transition-all duration-300">
                    <img src="https://www.google.com/favicon.ico" alt="Google" class="w-6 h-6">
                    <span class="font-semibold text-gray-700">Register with Google</span>
                </a>

                <a href="oauth/facebook.php" class="flex items-center justify-center gap-4 bg-[#1877F2] text-white px-6 py-4 rounded-2xl shadow-md hover:shadow-xl hover:bg-[#165FBF] transform hover:scale-105 transition-all duration-300">
                    <i class="fab fa-facebook-f text-xl"></i>
                    <span class="font-semibold">Register with Facebook</span>
                </a>
            </div>

            <!-- Login Link -->
            <div class="text-center mt-10">
                <p class="text-gray-600">
                    Already have an account? 
                    <a href="login.php" class="text-yellow-600 font-bold hover:text-yellow-700 hover:underline">
                        Login here
                    </a>
                </p>
            </div>
        </div>

        <!-- Footer Text -->
        <p class="text-center mt-10 text-gray-500 text-sm">
            © 2025 Cheeze Tea Alaminos Laguna • Made with love and milk tea
        </p>
    </div>
</div>

<style>
    @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(40px); }
        to   { opacity: 1; transform: translateY(0); }
    }
    .animate-fade-in { animation: fadeIn 1s ease-out; }
    .animate-fade-in-up { animation: fadeInUp 1.2s ease-out; }
</style>

<?php require 'includes/footer.php'; ?>