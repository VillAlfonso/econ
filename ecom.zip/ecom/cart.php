<?php 
$page_title = "Your Cart";
require 'includes/header.php'; 
require 'includes/navbar.php'; 
require 'includes/db.php';

if(!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo '<div class="text-center py-20"><h2 class="text-4xl">Your cart is empty</h2><a href="products.php" class="text-yellow-dark underline text-xl">Continue Shopping</a></div>';
    require 'includes/footer.php';
    exit();
}
?>

<div class="max-w-5xl mx-auto px-4 py-12">
    <h1 class="playfair text-5xl text-center mb-10">Your Cart</h1>
    <div class="bg-white rounded-xl shadow-lg p-8">
        <?php 
        $total = 0;
        foreach($_SESSION['cart'] as $id => $qty):
            $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
            $stmt->execute([$id]);
            $p = $stmt->fetch();
            if(!$p) continue;
            $subtotal = $p['price'] * $qty;
            $total += $subtotal;
        ?>
        <div class="flex items-center justify-between border-b py-6">
            <div class="flex items-center gap-6">
                <img src="uploads/<?php echo $p['image']; ?>" class="w-24 h-24 object-cover rounded">
                <div>
                    <h3 class="text-xl font-semibold"><?php echo htmlspecialchars($p['name']); ?></h3>
                    <p class="text-yellow-dark font-bold">$<?php echo $p['price']; ?> × <?php echo $qty; ?></p>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <p class="text-xl font-bold">$<?php echo number_format($subtotal, 2); ?></p>
                <a href="remove_from_cart.php?id=<?php echo $id; ?>" class="text-red-600 hover:underline">Remove</a>
            </div>
        </div>
        <?php endforeach; ?>
        
        <div class="text-right mt-8">
            <p class="text-3xl font-bold">Total: $<?php echo number_format($total, 2); ?></p>
            <a href="checkout.php" class="mt-4 inline-block bg-yellow-dark text-gray-900 px-10 py-4 rounded-lg text-xl hover:bg-yellow-warm font-semibold">Proceed to Checkout</a>
        </div>
    </div>
</div>

<?php require 'includes/footer.php'; ?>